import os
import numpy as np
import pandas as pd

def generate_student_dataset(n_samples: int = 1500, output_path: str = "ml/data/student_mastery_dataset.csv") -> pd.DataFrame:
    """
    Generates realistic student performance and revision history data.
    Features:
      - quiz_score_avg: 0.0 to 100.0
      - study_duration_hrs: 0.5 to 25.0
      - session_count: 1 to 20
      - topic_difficulty: 0.1 to 1.0
      - completion_rate: 0.1 to 1.0
      - recent_quiz_score: 0.0 to 100.0
      - revision_frequency: 0 to 8
    Target:
      - mastered: 0 or 1
    """
    np.random.seed(42)
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    quiz_score_avg = np.random.normal(68, 16, n_samples).clip(15, 100)
    study_duration_hrs = np.random.exponential(5.0, n_samples).clip(0.5, 30.0)
    session_count = (study_duration_hrs / np.random.uniform(0.7, 1.5, n_samples)).astype(int).clip(1, 25)
    topic_difficulty = np.random.uniform(0.2, 0.95, n_samples)
    completion_rate = (0.5 + 0.5 * (study_duration_hrs / 15.0) + np.random.normal(0, 0.1, n_samples)).clip(0.1, 1.0)
    recent_quiz_score = (quiz_score_avg + np.random.normal(2, 8, n_samples)).clip(10, 100)
    revision_frequency = (session_count * np.random.uniform(0.2, 0.6, n_samples)).astype(int).clip(0, 10)

    # Ground truth latent mastery score with noise
    latent_score = (
        0.35 * (quiz_score_avg / 100.0) +
        0.25 * (recent_quiz_score / 100.0) +
        0.15 * completion_rate +
        0.15 * np.log1p(study_duration_hrs) / np.log1p(30.0) +
        0.10 * (revision_frequency / 10.0) -
        0.20 * topic_difficulty +
        np.random.normal(0, 0.08, n_samples)
    )

    # Mastered threshold: probability sigmoid
    prob = 1.0 / (1.0 + np.exp(-10.0 * (latent_score - 0.52)))
    mastered = (np.random.rand(n_samples) < prob).astype(int)

    df = pd.DataFrame({
        "quiz_score_avg": np.round(quiz_score_avg, 2),
        "study_duration_hrs": np.round(study_duration_hrs, 2),
        "session_count": session_count,
        "topic_difficulty": np.round(topic_difficulty, 2),
        "completion_rate": np.round(completion_rate, 2),
        "recent_quiz_score": np.round(recent_quiz_score, 2),
        "revision_frequency": revision_frequency,
        "mastered": mastered
    })

    df.to_csv(output_path, index=False)
    print(f"Generated {n_samples} student samples at {output_path}. Mastered ratio: {mastered.mean():.2%}")
    return df

if __name__ == "__main__":
    generate_student_dataset()
