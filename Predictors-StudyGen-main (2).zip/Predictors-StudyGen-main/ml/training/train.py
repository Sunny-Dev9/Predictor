import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))
import json
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

def train_mastery_models():
    data_path = "ml/data/student_mastery_dataset.csv"
    if not os.path.exists(data_path):
        from ml.data.generate_dataset import generate_student_dataset
        generate_student_dataset(output_path=data_path)

    df = pd.read_csv(data_path)
    feature_cols = [
        "quiz_score_avg",
        "study_duration_hrs",
        "session_count",
        "topic_difficulty",
        "completion_rate",
        "recent_quiz_score",
        "revision_frequency"
    ]
    target_col = "mastered"

    X = df[feature_cols]
    y = df[target_col]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

    models = {
        "LogisticRegression": LogisticRegression(max_iter=1000, random_state=42),
        "RandomForest": RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42)
    }

    best_model_name = None
    best_f1 = -1.0
    best_model = None
    evaluation_results = {}

    # MLflow tracking if available
    try:
        import mlflow
        mlflow.set_tracking_uri("sqlite:///mlflow.db")
        mlflow.set_experiment("studygen_mastery_predictor")
    except Exception as e:
        print(f"MLflow tracking setup info: {e}")
        mlflow = None

    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]

        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred)
        rec = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        roc = roc_auc_score(y_test, y_prob)

        metrics = {
            "accuracy": round(float(acc), 4),
            "precision": round(float(prec), 4),
            "recall": round(float(rec), 4),
            "f1_score": round(float(f1), 4),
            "roc_auc": round(float(roc), 4)
        }
        evaluation_results[name] = metrics
        print(f"[{name}] Acc: {acc:.4f} | Prec: {prec:.4f} | Rec: {rec:.4f} | F1: {f1:.4f} | ROC-AUC: {roc:.4f}")

        if mlflow:
            try:
                with mlflow.start_run(run_name=f"studygen_{name.lower()}"):
                    mlflow.log_params(model.get_params())
                    mlflow.log_metrics(metrics)
            except Exception as ex:
                print(f"MLflow log error: {ex}")

        if f1 > best_f1:
            best_f1 = f1
            best_model_name = name
            best_model = model

    os.makedirs("ml/models", exist_ok=True)
    os.makedirs("ml/experiments", exist_ok=True)
    os.makedirs("backend/app/ml", exist_ok=True)

    # Save artifacts
    model_artifact_path = "ml/models/mastery_predictor.joblib"
    backend_artifact_path = "backend/app/ml/mastery_predictor.joblib"
    
    artifact_payload = {
        "model": best_model,
        "model_name": best_model_name,
        "feature_names": feature_cols,
        "metrics": evaluation_results[best_model_name]
    }
    
    joblib.dump(artifact_payload, model_artifact_path)
    joblib.dump(artifact_payload, backend_artifact_path)

    with open("ml/experiments/metrics.json", "w") as f:
        json.dump(evaluation_results, f, indent=2)

    print(f"\nBest Model: {best_model_name} (F1: {best_f1:.4f}) successfully saved to {model_artifact_path}")
    return evaluation_results

if __name__ == "__main__":
    train_mastery_models()
