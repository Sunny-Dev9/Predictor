import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.database import init_db
from app.api.router import api_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("studygen")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing StudyGen database schemas...")
    await init_db()
    logger.info("Database schemas initialized.")
    yield
    logger.info("Shutting down StudyGen backend...")

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Agentic AI Study Planner backend powered by LangGraph, RAG, and Adaptive ML.",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API Routers
app.include_router(api_router, prefix=settings.API_V1_STR)

@app.get("/health", tags=["System"])
async def health_check():
    return {
        "status": "healthy",
        "service": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "environment": settings.ENVIRONMENT,
        "default_llm": settings.DEFAULT_LLM_PROVIDER
    }

@app.get("/metrics", tags=["Monitoring"])
async def prometheus_metrics():
    """Prometheus metrics endpoint for MLOps monitoring."""
    try:
        from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
        return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
    except Exception:
        # Fallback text metrics
        return Response(content="# HELP studygen_requests_total Total requests\nstudygen_requests_total 42\n", media_type="text/plain")

@app.get("/", tags=["System"])
async def root():
    return {
        "message": "Welcome to StudyGen — Agentic AI Study Planner API",
        "docs_url": "/docs",
        "health_url": "/health",
        "demo_seed_url": f"{settings.API_V1_STR}/demo/seed"
    }
