from datetime import datetime, timedelta, timezone
from typing import Dict, Any

class MasteryEngine:
    @staticmethod
    def calculate_composite_mastery(
        quiz_performance: float,   # 0.0 to 1.0 (from quiz percentage / 100)
        completion_rate: float,    # 0.0 to 1.0 (tasks completed / tasks scheduled)
        consistency_score: float,  # 0.0 to 1.0 (streak and active days)
        recent_performance: float  # 0.0 to 1.0 (latest test score)
    ) -> float:
        """
        Transparent mastery model formula:
        mastery = 0.4 * quiz_perf + 0.2 * completion + 0.2 * consistency + 0.2 * recent_perf
        """
        raw = (
            0.40 * quiz_performance +
            0.20 * completion_rate +
            0.20 * consistency_score +
            0.20 * recent_performance
        )
        return round(max(0.0, min(1.0, raw)), 3)

    @staticmethod
    def calculate_next_revision(mastery_score: float, last_studied: datetime = None) -> datetime:
        """
        Calculates spaced repetition revision due date based on current mastery level.
        """
        now = last_studied or datetime.now(timezone.utc)
        if mastery_score < 0.50:
            # Urgent review needed in 1 day
            return now + timedelta(days=1)
        elif mastery_score < 0.70:
            # Intermediate review in 3 days
            return now + timedelta(days=3)
        elif mastery_score < 0.85:
            # Good retention review in 7 days
            return now + timedelta(days=7)
        else:
            # Strong retention review in 14 days
            return now + timedelta(days=14)

    @classmethod
    def evaluate_quiz_and_adapt(
        cls,
        quiz_score_pct: float,
        previous_mastery: float,
        study_count: int,
        completion_rate: float = 0.8,
        consistency_score: float = 0.8
    ) -> Dict[str, Any]:
        """
        Evaluates quiz score, recalculates mastery, and returns adaptive routing action.
        """
        quiz_ratio = quiz_score_pct / 100.0
        new_mastery = cls.calculate_composite_mastery(
            quiz_performance=quiz_ratio,
            completion_rate=completion_rate,
            consistency_score=consistency_score,
            recent_performance=quiz_ratio
        )

        now = datetime.now(timezone.utc)
        revision_due = cls.calculate_next_revision(new_mastery, now)

        # Adaptive routing rules
        if quiz_score_pct < 50.0:
            action = "SCHEDULE_REMEDIAL"
            recommendation = (
                f"Quiz score is {int(quiz_score_pct)}%. Mastery dropped to {int(new_mastery * 100)}%. "
                f"Added 2 remedial revision sessions to solidify core prerequisites."
            )
            is_remedial = True
            replan_required = True
        elif 50.0 <= quiz_score_pct < 75.0:
            action = "SCHEDULE_PRACTICE"
            recommendation = (
                f"Quiz score is {int(quiz_score_pct)}%. Solid foundation, but needs additional problem-solving practice."
            )
            is_remedial = False
            replan_required = False
        else:
            action = "ADVANCE_TOPIC"
            recommendation = (
                f"Quiz score is {int(quiz_score_pct)}%! High mastery achieved ({int(new_mastery * 100)}%). "
                f"Ready to unlock advanced topics and spaced maintenance reviews."
            )
            is_remedial = False
            replan_required = False

        return {
            "mastery_score": new_mastery,
            "action": action,
            "recommendation": recommendation,
            "is_remedial": is_remedial,
            "replan_required": replan_required,
            "revision_due": revision_due
        }
