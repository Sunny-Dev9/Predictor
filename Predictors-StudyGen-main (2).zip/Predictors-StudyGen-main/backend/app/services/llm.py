import json
import logging
import re
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from app.core.config import settings

logger = logging.getLogger(__name__)

class BaseLLMProvider(ABC):
    @abstractmethod
    async def generate_text(self, prompt: str, system: Optional[str] = None) -> str:
        pass

    @abstractmethod
    async def generate_json(self, prompt: str, system: Optional[str] = None) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        pass

class MockProvider(BaseLLMProvider):
    """
    Intelligent Mock Provider for offline/zero-API-key hackathon execution and automated testing.
    Provides realistic, contextual outputs for syllabus analysis, quizzes, and tutor queries.
    """

    async def generate_text(self, prompt: str, system: Optional[str] = None) -> str:
        prompt_lower = prompt.lower()
        if "avl" in prompt_lower or "tree" in prompt_lower:
            return (
                "An **AVL Tree** is a self-balancing Binary Search Tree (BST) where the difference "
                "between heights of left and right subtrees (the balance factor) cannot be more than 1 for all nodes.\n\n"
                "### Key Operations:\n"
                "1. **Balance Factor**: $BF = \\text{height}(left) - \\text{height}(right) \\in \\{-1, 0, +1\\}$.\n"
                "2. **Rotations**: Used to rebalance upon insertion or deletion:\n"
                "   - **LL Rotation** (Single Right Rotation)\n"
                "   - **RR Rotation** (Single Left Rotation)\n"
                "   - **LR Rotation** (Left-Right Double Rotation)\n"
                "   - **RL Rotation** (Right-Left Double Rotation)\n\n"
                "Time Complexity: Search, Insert, and Delete are guaranteed $O(\\log n)$ in the worst case."
            )
        elif "explain" in prompt_lower or "what is" in prompt_lower:
            return (
                f"Here is a comprehensive breakdown based on your study materials:\n\n"
                f"The concept involves foundational theory followed by practical implementations. "
                f"Make sure to review edge cases, time/space complexity trade-offs, and solve at least 3 practice problems."
            )
        return "StudyGen AI Tutor: I have analyzed your notes and current learning progress to assist your revision."

    async def generate_json(self, prompt: str, system: Optional[str] = None) -> Dict[str, Any]:
        prompt_lower = prompt.lower()

        # Syllabus analysis prompt detection
        if "syllabus" in prompt_lower or "topics" in prompt_lower or "analyze" in prompt_lower:
            if "dbms" in prompt_lower:
                return {
                    "subject_name": "Database Management Systems",
                    "total_topics": 5,
                    "total_estimated_hours": 18.0,
                    "topics": [
                        {"name": "Relational Model & SQL", "description": "Relational algebra, DDL/DML, joins, subqueries", "difficulty": 0.4, "priority": 0.9, "estimated_hours": 3.5, "subtopics": ["Relational Algebra", "Complex Joins", "Aggregations"]},
                        {"name": "ER Modeling & Normalization", "description": "ER to relational mapping, 1NF, 2NF, 3NF, BCNF", "difficulty": 0.7, "priority": 0.95, "estimated_hours": 4.5, "subtopics": ["Functional Dependencies", "3NF vs BCNF", "Decomposition"]},
                        {"name": "Transaction & Concurrency Control", "description": "ACID properties, serializability, 2PL, deadlock prevention", "difficulty": 0.85, "priority": 0.9, "estimated_hours": 4.0, "subtopics": ["Conflict Serializability", "Two-Phase Locking", "Deadlocks"]},
                        {"name": "Indexing & B+ Trees", "description": "Dense vs sparse indexing, B-Tree and B+ Tree structures", "difficulty": 0.8, "priority": 0.8, "estimated_hours": 3.5, "subtopics": ["B+ Tree Search", "Splitting & Merging", "Clustered Index"]},
                        {"name": "Crash Recovery & Logging", "description": "WAL, checkpoints, ARIES recovery algorithm", "difficulty": 0.75, "priority": 0.7, "estimated_hours": 2.5, "subtopics": ["Write-Ahead Logging", "Checkpointing", "Redo/Undo"]}
                    ],
                    "analysis_notes": "Syllabus organized by theoretical foundation to systems implementation with priority placed on Normalization and Concurrency."
                }
            # Default / DSA
            return {
                "subject_name": "Data Structures & Algorithms",
                "total_topics": 6,
                "total_estimated_hours": 22.0,
                "topics": [
                    {"name": "Arrays & Strings", "description": "Two pointers, sliding window, prefix sums", "difficulty": 0.3, "priority": 0.8, "estimated_hours": 3.0, "subtopics": ["Two Pointers", "Sliding Window", "Kadane's Algorithm"]},
                    {"name": "Linked Lists", "description": "Singly, doubly, cycle detection, reversal", "difficulty": 0.4, "priority": 0.75, "estimated_hours": 2.5, "subtopics": ["Fast & Slow Pointers", "Reversing Linked List", "Merge K Lists"]},
                    {"name": "Stacks & Queues", "description": "Monotonic stack, queue using stacks, sliding window maximum", "difficulty": 0.5, "priority": 0.7, "estimated_hours": 3.0, "subtopics": ["Next Greater Element", "Min Stack", "Deque"]},
                    {"name": "Binary Trees & BST", "description": "Traversals, height, LCA, BST validation, balancing", "difficulty": 0.8, "priority": 0.95, "estimated_hours": 5.0, "subtopics": ["Tree Traversals", "Lowest Common Ancestor", "Balanced BST / AVL"]},
                    {"name": "Graph Algorithms", "description": "BFS, DFS, Dijkstra, Topo sort, MST", "difficulty": 0.85, "priority": 0.9, "estimated_hours": 5.0, "subtopics": ["BFS/DFS", "Dijkstra's Algorithm", "Topological Sort"]},
                    {"name": "Dynamic Programming", "description": "0/1 Knapsack, LCS, LIS, Memoization vs Tabulation", "difficulty": 0.9, "priority": 0.9, "estimated_hours": 3.5, "subtopics": ["State Definition", "Knapsack Variations", "LCS Pattern"]}
                ],
                "analysis_notes": "Identified high-yield exam topics: Binary Trees & Graph Algorithms. Prerequisites order: Linear structures -> Hierarchical structures -> Dynamic Programming."
            }

        # Quiz generation prompt detection
        if "quiz" in prompt_lower or "questions" in prompt_lower:
            return {
                "questions": [
                    {
                        "question_text": "What is the worst-case time complexity of searching for an element in an unbalanced Binary Search Tree?",
                        "question_type": "MCQ",
                        "options": ["O(1)", "O(log n)", "O(n)", "O(n log n)"],
                        "correct_answer": "O(n)",
                        "explanation": "In an unbalanced (skewed) Binary Search Tree, all nodes degenerate into a single linked list, making worst-case search O(n)."
                    },
                    {
                        "question_text": "In an AVL tree, what is the maximum permissible absolute difference between the heights of the left and right subtrees?",
                        "question_type": "MCQ",
                        "options": ["0", "1", "2", "log n"],
                        "correct_answer": "1",
                        "explanation": "The AVL balance factor invariant requires |height(left) - height(right)| <= 1 for every node in the tree."
                    },
                    {
                        "question_text": "Which tree traversal visits the root node between its left and right subtrees?",
                        "question_type": "MCQ",
                        "options": ["Preorder", "Inorder", "Postorder", "Level-order"],
                        "correct_answer": "Inorder",
                        "explanation": "Inorder traversal visits Left Subtree -> Root -> Right Subtree. For a BST, this produces sorted order."
                    },
                    {
                        "question_text": "Which rotation is required when a new node is inserted into the right subtree of the left child of an unbalanced node?",
                        "question_type": "MCQ",
                        "options": ["Left-Left (LL)", "Right-Right (RR)", "Left-Right (LR)", "Right-Left (RL)"],
                        "correct_answer": "Left-Right (LR)",
                        "explanation": "An insertion into the right subtree of a left child creates a zig-zag shape requiring a Left rotation followed by a Right rotation (LR rotation)."
                    }
                ]
            }

        # Fallback generic JSON
        return {"status": "ok", "message": "Processed mock response"}

    async def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        # Generate deterministic, normalized 128-dimensional mock embeddings based on text hashes
        embeddings = []
        for text in texts:
            vec = [0.0] * 128
            words = re.findall(r'\w+', text.lower())
            for i, word in enumerate(words):
                h = hash(word) % 128
                vec[h] += 1.0 / (1.0 + (i * 0.05))
            # Normalize vector
            norm = (sum(x * x for x in vec) ** 0.5) or 1.0
            embeddings.append([x / norm for x in vec])
        return embeddings

class OpenAIProvider(BaseLLMProvider):
    def __init__(self, api_key: str, model: str = "gpt-4o-mini"):
        self.api_key = api_key
        self.model = model
        try:
            from openai import AsyncOpenAI
            self.client = AsyncOpenAI(api_key=api_key)
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI client: {e}")
            self.client = None

    async def generate_text(self, prompt: str, system: Optional[str] = None) -> str:
        if not self.client:
            return await MockProvider().generate_text(prompt, system)
        try:
            messages = []
            if system:
                messages.append({"role": "system", "content": system})
            messages.append({"role": "user", "content": prompt})
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.2
            )
            return response.choices[0].message.content or ""
        except Exception as e:
            logger.error(f"OpenAI generate_text error: {e}. Falling back to MockProvider.")
            return await MockProvider().generate_text(prompt, system)

    async def generate_json(self, prompt: str, system: Optional[str] = None) -> Dict[str, Any]:
        if not self.client:
            return await MockProvider().generate_json(prompt, system)
        try:
            messages = []
            if system:
                messages.append({"role": "system", "content": system + "\nRespond strictly in valid JSON."})
            else:
                messages.append({"role": "system", "content": "Respond strictly in valid JSON."})
            messages.append({"role": "user", "content": prompt})
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                response_format={"type": "json_object"},
                temperature=0.1
            )
            return json.loads(response.choices[0].message.content or "{}")
        except Exception as e:
            logger.error(f"OpenAI generate_json error: {e}. Falling back to MockProvider.")
            return await MockProvider().generate_json(prompt, system)

    async def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        if not self.client:
            return await MockProvider().get_embeddings(texts)
        try:
            resp = await self.client.embeddings.create(
                model="text-embedding-3-small",
                input=texts
            )
            return [data.embedding for data in resp.data]
        except Exception as e:
            logger.error(f"OpenAI embeddings error: {e}. Falling back to MockProvider.")
            return await MockProvider().get_embeddings(texts)

class GeminiProvider(BaseLLMProvider):
    def __init__(self, api_key: str, model: str = "gemini-1.5-flash"):
        self.api_key = api_key
        self.model_name = model
        try:
            import google.generativeai as genai
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel(model)
        except Exception as e:
            logger.error(f"Failed to initialize Gemini: {e}")
            self.model = None

    async def generate_text(self, prompt: str, system: Optional[str] = None) -> str:
        if not self.model:
            return await MockProvider().generate_text(prompt, system)
        try:
            full_prompt = f"{system}\n\n{prompt}" if system else prompt
            resp = self.model.generate_content(full_prompt)
            return resp.text or ""
        except Exception as e:
            logger.error(f"Gemini generate_text error: {e}. Falling back to MockProvider.")
            return await MockProvider().generate_text(prompt, system)

    async def generate_json(self, prompt: str, system: Optional[str] = None) -> Dict[str, Any]:
        if not self.model:
            return await MockProvider().generate_json(prompt, system)
        try:
            full_prompt = f"{system}\n\nOutput strictly valid JSON:\n{prompt}" if system else f"Output strictly valid JSON:\n{prompt}"
            resp = self.model.generate_content(
                full_prompt,
                generation_config={"response_mime_type": "application/json"}
            )
            return json.loads(resp.text)
        except Exception as e:
            logger.error(f"Gemini generate_json error: {e}. Falling back to MockProvider.")
            return await MockProvider().generate_json(prompt, system)

    async def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        # Fallback to local deterministic mock embeddings if google-genai embedding client is unavailable
        return await MockProvider().get_embeddings(texts)

def get_llm_provider(provider_name: Optional[str] = None) -> BaseLLMProvider:
    provider = (provider_name or settings.DEFAULT_LLM_PROVIDER).lower()
    if provider == "openai" and settings.OPENAI_API_KEY:
        return OpenAIProvider(api_key=settings.OPENAI_API_KEY, model=settings.OPENAI_MODEL)
    elif provider == "gemini" and settings.GEMINI_API_KEY:
        return GeminiProvider(api_key=settings.GEMINI_API_KEY, model=settings.GEMINI_MODEL)
    return MockProvider()
