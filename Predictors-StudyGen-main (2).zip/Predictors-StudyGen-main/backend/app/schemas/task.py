from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

class StudySessionCreate(BaseModel):
    task_id: str
    duration_minutes: int
    focus_score: float = 1.0
    notes: Optional[str] = None

class StudySessionResponse(BaseModel):
    id: str
    task_id: str
    duration_minutes: int
    focus_score: float
    notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True

class TaskBase(BaseModel):
    topic_id: str
    title: str
    scheduled_date: str # YYYY-MM-DD
    start_time: Optional[str] = "18:00"
    end_time: Optional[str] = "19:00"
    duration_minutes: int = 60
    task_type: str = "LEARNING" # LEARNING, REVISION, PRACTICE, QUIZ
    priority: str = "High"
    reason: Optional[str] = None
    is_remedial: bool = False

class TaskCreate(TaskBase):
    pass

class TaskUpdate(BaseModel):
    status: Optional[str] = None # PENDING, COMPLETED, SKIPPED
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    scheduled_date: Optional[str] = None
    notes: Optional[str] = None

class TaskTopicInfo(BaseModel):
    id: str
    name: str
    subject_name: Optional[str] = None
    difficulty: float
    priority: float

class TaskResponse(TaskBase):
    id: str
    user_id: str
    status: str
    completed_at: Optional[datetime] = None
    created_at: datetime
    topic_info: Optional[TaskTopicInfo] = None

    class Config:
        from_attributes = True

class PlanGenerateRequest(BaseModel):
    start_date: Optional[str] = None # YYYY-MM-DD (defaults to today)
    days_ahead: int = 14
    daily_available_hours: Optional[float] = None
    preferred_study_time: Optional[str] = None

class PlanResponse(BaseModel):
    total_tasks: int
    total_study_hours: float
    start_date: str
    end_date: str
    tasks: List[TaskResponse]
    explanation: str

class ReplanRequest(BaseModel):
    reason: Optional[str] = "Automatic dynamic schedule update based on recent mastery and progress."
    triggered_topic_id: Optional[str] = None
