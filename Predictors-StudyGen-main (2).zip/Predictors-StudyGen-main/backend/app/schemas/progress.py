from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel

class WeakTopicItem(BaseModel):
    topic_id: str
    topic_name: str
    subject_name: str
    mastery_score: float
    difficulty: float
    priority: float
    revision_due: Optional[datetime] = None
    reason: str

class StrongTopicItem(BaseModel):
    topic_id: str
    topic_name: str
    subject_name: str
    mastery_score: float

class UpcomingExamItem(BaseModel):
    id: str
    name: str
    subject_name: Optional[str] = None
    exam_date: datetime
    days_left: int

class SubjectMasteryItem(BaseModel):
    subject_name: str
    average_mastery: float
    topics_count: int

class WeeklyStudyItem(BaseModel):
    day: str # Mon, Tue, etc.
    hours: float

class ProgressOverviewResponse(BaseModel):
    overall_mastery: float
    completion_rate: float
    completed_tasks_count: int
    total_tasks_count: int
    streak_count: int
    total_study_minutes: int
    weak_topics: List[WeakTopicItem]
    strong_topics: List[StrongTopicItem]
    upcoming_exams: List[UpcomingExamItem]
    ai_recommendations: List[str]
    subject_mastery: List[SubjectMasteryItem]
    weekly_study: List[WeeklyStudyItem]

class AnalyticsResponse(BaseModel):
    subject_mastery: List[SubjectMasteryItem]
    weekly_study: List[WeeklyStudyItem]
    quiz_trend: List[Dict[str, Any]]
    completion_trend: List[Dict[str, Any]]
