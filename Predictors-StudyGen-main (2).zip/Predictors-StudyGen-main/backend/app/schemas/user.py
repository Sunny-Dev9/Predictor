from typing import Optional
from datetime import datetime
from pydantic import BaseModel, EmailStr

class ProfileBase(BaseModel):
    target_exam_name: Optional[str] = "Semester Finals"
    exam_date: Optional[datetime] = None
    available_hours_per_day: float = 3.0
    preferred_study_time: str = "Evening"
    max_daily_study_time: float = 4.0
    learning_style: Optional[str] = "Visual & Practical"
    onboarding_completed: bool = False

class ProfileUpdate(ProfileBase):
    pass

class ProfileResponse(ProfileBase):
    id: str
    user_id: str
    streak_count: int
    total_study_minutes: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class UserBase(BaseModel):
    email: EmailStr
    full_name: str

class UserCreate(UserBase):
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(UserBase):
    id: str
    is_active: bool
    created_at: datetime
    profile: Optional[ProfileResponse] = None

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserResponse
