from typing import List, Optional, Any
from datetime import datetime
from pydantic import BaseModel

class QuestionOption(BaseModel):
    id: str
    text: str

class QuizQuestionCreate(BaseModel):
    question_text: str
    question_type: str = "MCQ"
    options: List[str]
    correct_answer: str
    explanation: Optional[str] = None

class QuizQuestionResponse(BaseModel):
    id: str
    question_text: str
    question_type: str
    options: Optional[Any] = None
    student_answer: Optional[str] = None
    is_correct: Optional[bool] = None
    explanation: Optional[str] = None

    class Config:
        from_attributes = True

class QuizGenerateRequest(BaseModel):
    topic_id: str
    num_questions: int = 4
    difficulty: Optional[float] = None
    include_short_answer: bool = False

class QuizAnswerSubmission(BaseModel):
    question_id: str
    student_answer: str

class QuizSubmitRequest(BaseModel):
    attempt_id: str
    answers: List[QuizAnswerSubmission]
    time_taken_seconds: int = 120

class QuizAttemptResponse(BaseModel):
    id: str
    topic_id: str
    topic_name: Optional[str] = None
    total_questions: int
    correct_answers: int
    score_percentage: float
    feedback: Optional[str] = None
    time_taken_seconds: int
    created_at: datetime
    questions: List[QuizQuestionResponse] = []
    replan_triggered: bool = False
    adaptive_recommendation: Optional[str] = None

    class Config:
        from_attributes = True
