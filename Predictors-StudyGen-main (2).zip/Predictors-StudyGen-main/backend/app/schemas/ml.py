from typing import Dict, Any, List, Optional
from pydantic import BaseModel

class MasteryPredictRequest(BaseModel):
    quiz_score_avg: float = 65.0       # 0 - 100
    study_duration_hrs: float = 3.5    # total study hours on topic
    session_count: int = 4             # number of sessions
    topic_difficulty: float = 0.7      # 0.1 to 1.0
    completion_rate: float = 0.75      # 0.0 to 1.0
    recent_quiz_score: float = 70.0    # latest quiz score
    revision_frequency: int = 2        # times revised

class MasteryPredictResponse(BaseModel):
    mastery_probability: float         # 0.0 to 1.0 probability of mastering
    is_mastery_likely: bool
    recommended_action: str            # e.g., "Schedule 1 practice session", "Ready for advanced topics"
    confidence_level: str              # High, Medium, Low
    feature_importances: Dict[str, float] = {}
    model_version: str = "random_forest_v1.0"
