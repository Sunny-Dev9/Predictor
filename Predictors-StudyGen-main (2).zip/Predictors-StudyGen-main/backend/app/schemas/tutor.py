from typing import List, Optional
from pydantic import BaseModel

class Citation(BaseModel):
    document_id: str
    document_name: str
    page_number: int
    snippet: str
    relevance_score: float

class ChatRequest(BaseModel):
    message: str
    subject_id: Optional[str] = None
    topic_id: Optional[str] = None

class ChatResponse(BaseModel):
    answer: str
    citations: List[Citation] = []
    follow_up_questions: List[str] = []
    related_topic_id: Optional[str] = None
