from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

class SubtopicResponse(BaseModel):
    id: str
    name: str
    order_index: int

    class Config:
        from_attributes = True

class TopicMasterySimple(BaseModel):
    mastery_score: float
    difficulty: float
    priority: float
    last_studied: Optional[datetime] = None
    study_count: int
    quiz_score: float
    revision_due: Optional[datetime] = None

    class Config:
        from_attributes = True

class TopicBase(BaseModel):
    name: str
    description: Optional[str] = None
    difficulty: float = 0.5
    priority: float = 0.7
    estimated_hours: float = 2.0
    order_index: int = 0

class TopicCreate(TopicBase):
    subject_id: str
    subtopics: Optional[List[str]] = []

class TopicResponse(TopicBase):
    id: str
    subject_id: str
    subtopics: List[SubtopicResponse] = []
    mastery: Optional[TopicMasterySimple] = None
    created_at: datetime

    class Config:
        from_attributes = True

class ExamBase(BaseModel):
    name: str
    exam_date: datetime
    weightage: float = 1.0
    target_score: float = 85.0
    subject_id: Optional[str] = None

class ExamCreate(ExamBase):
    pass

class ExamResponse(ExamBase):
    id: str
    user_id: str
    created_at: datetime

    class Config:
        from_attributes = True

class SubjectBase(BaseModel):
    name: str
    code: Optional[str] = None
    description: Optional[str] = None
    color: Optional[str] = "#3B82F6"

class SubjectCreate(SubjectBase):
    pass

class SubjectResponse(SubjectBase):
    id: str
    user_id: str
    topics: List[TopicResponse] = []
    exams: List[ExamResponse] = []
    created_at: datetime

    class Config:
        from_attributes = True

class SyllabusAnalyzeRequest(BaseModel):
    subject_name: str
    raw_syllabus_text: str
    estimated_exam_days: Optional[int] = 20

class AnalyzedTopicItem(BaseModel):
    name: str
    description: str
    difficulty: float
    priority: float
    estimated_hours: float
    subtopics: List[str] = []
    prerequisites: List[str] = []

class SyllabusAnalyzeResponse(BaseModel):
    subject_name: str
    total_topics: int
    total_estimated_hours: float
    topics: List[AnalyzedTopicItem]
    graph_edges: List[dict] = []
    analysis_notes: str
