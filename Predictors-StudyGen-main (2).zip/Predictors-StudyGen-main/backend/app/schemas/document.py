from typing import List, Optional, Any
from datetime import datetime
from pydantic import BaseModel

class DocumentChunkResponse(BaseModel):
    id: str
    page_number: int
    chunk_index: int
    content: str
    metadata_json: Optional[Any] = None

    class Config:
        from_attributes = True

class DocumentResponse(BaseModel):
    id: str
    filename: str
    file_type: str
    file_size: int
    num_pages: int
    status: str
    error_message: Optional[str] = None
    created_at: datetime
    chunks_count: Optional[int] = 0

    class Config:
        from_attributes = True
