import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, Float, ForeignKey, Integer, Text, Boolean
from sqlalchemy.orm import relationship
from app.core.database import Base

def generate_uuid() -> str:
    return str(uuid.uuid4())

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

class StudyTask(Base):
    __tablename__ = "study_tasks"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    topic_id = Column(String(36), ForeignKey("topics.id", ondelete="CASCADE"), nullable=False)
    
    title = Column(String(255), nullable=False)
    scheduled_date = Column(String(10), nullable=False)  # YYYY-MM-DD
    start_time = Column(String(10), nullable=True)       # e.g. "18:00"
    end_time = Column(String(10), nullable=True)         # e.g. "19:00"
    duration_minutes = Column(Integer, default=60)
    
    task_type = Column(String(50), default="LEARNING")   # LEARNING, REVISION, PRACTICE, QUIZ
    status = Column(String(50), default="PENDING")       # PENDING, COMPLETED, SKIPPED
    priority = Column(String(50), default="High")        # High, Medium, Low
    
    # Explainable AI reason: "Why was this task scheduled?"
    reason = Column(Text, nullable=True)
    
    is_remedial = Column(Boolean, default=False)
    completed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    user = relationship("User", back_populates="tasks")
    topic = relationship("Topic", back_populates="tasks")
    sessions = relationship("StudySession", back_populates="task", cascade="all, delete-orphan")

class StudySession(Base):
    __tablename__ = "study_sessions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    task_id = Column(String(36), ForeignKey("study_tasks.id", ondelete="CASCADE"), nullable=False)
    
    duration_minutes = Column(Integer, default=45)
    focus_score = Column(Float, default=1.0)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=utc_now)

    task = relationship("StudyTask", back_populates="sessions")
