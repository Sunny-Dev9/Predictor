import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, Float, ForeignKey, Integer, Text, Boolean, JSON
from sqlalchemy.orm import relationship
from app.core.database import Base

def generate_uuid() -> str:
    return str(uuid.uuid4())

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

class QuizAttempt(Base):
    __tablename__ = "quiz_attempts"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    topic_id = Column(String(36), ForeignKey("topics.id", ondelete="CASCADE"), nullable=False)
    
    total_questions = Column(Integer, default=5)
    correct_answers = Column(Integer, default=0)
    score_percentage = Column(Float, default=0.0)
    feedback = Column(Text, nullable=True)
    time_taken_seconds = Column(Integer, default=0)
    created_at = Column(DateTime, default=utc_now)

    user = relationship("User", back_populates="quiz_attempts")
    questions = relationship("QuizQuestion", back_populates="attempt", cascade="all, delete-orphan")

class QuizQuestion(Base):
    __tablename__ = "quiz_questions"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    attempt_id = Column(String(36), ForeignKey("quiz_attempts.id", ondelete="CASCADE"), nullable=False)
    
    question_text = Column(Text, nullable=False)
    question_type = Column(String(50), default="MCQ") # MCQ, SHORT_ANSWER
    options = Column(JSON, nullable=True)             # List of choices for MCQ
    correct_answer = Column(Text, nullable=False)
    student_answer = Column(Text, nullable=True)
    is_correct = Column(Boolean, nullable=True)
    explanation = Column(Text, nullable=True)

    attempt = relationship("QuizAttempt", back_populates="questions")
