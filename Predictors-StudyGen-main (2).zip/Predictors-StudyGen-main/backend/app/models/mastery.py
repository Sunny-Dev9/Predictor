import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, Float, ForeignKey, Integer
from sqlalchemy.orm import relationship
from app.core.database import Base

def generate_uuid() -> str:
    return str(uuid.uuid4())

def utc_now() -> datetime:
    return datetime.now(timezone.utc)

class TopicMastery(Base):
    __tablename__ = "topic_mastery"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    topic_id = Column(String(36), ForeignKey("topics.id", ondelete="CASCADE"), unique=True, nullable=False)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    
    mastery_score = Column(Float, default=0.2)          # 0.0 to 1.0
    difficulty = Column(Float, default=0.5)             # 0.1 to 1.0
    priority = Column(Float, default=0.7)               # 0.1 to 1.0
    last_studied = Column(DateTime, nullable=True)
    study_count = Column(Integer, default=0)
    quiz_score = Column(Float, default=0.0)             # 0 to 100
    confidence = Column(Float, default=0.5)             # 0.0 to 1.0
    revision_due = Column(DateTime, nullable=True)
    
    # Components for transparent formula
    recent_performance = Column(Float, default=0.0)     # 0.0 to 1.0
    completion_rate = Column(Float, default=0.0)        # 0.0 to 1.0
    consistency_score = Column(Float, default=0.5)      # 0.0 to 1.0
    
    # ML predicted probability of mastering
    predicted_mastery_prob = Column(Float, default=0.5) # 0.0 to 1.0
    
    created_at = Column(DateTime, default=utc_now)
    updated_at = Column(DateTime, default=utc_now, onupdate=utc_now)

    topic = relationship("Topic", back_populates="mastery")
