import os
import joblib
import numpy as np
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

class MasteryPredictor:
    def __init__(self, model_path: str = "backend/app/ml/mastery_predictor.joblib"):
        self.model_path = model_path
        self.model = None
        self.feature_names = [
            "quiz_score_avg",
            "study_duration_hrs",
            "session_count",
            "topic_difficulty",
            "completion_rate",
            "recent_quiz_score",
            "revision_frequency"
        ]
        self._load_or_fallback()

    def _load_or_fallback(self):
        if os.path.exists(self.model_path):
            try:
                payload = joblib.load(self.model_path)
                self.model = payload["model"]
                self.model_name = payload.get("model_name", "RandomForest")
                logger.info(f"Loaded ML mastery model: {self.model_name}")
                return
            except Exception as e:
                logger.warning(f"Error loading saved model: {e}")

        # Lightweight fallback predictor if model file is not present yet
        self.model = None
        self.model_name = "HeuristicPredictor"

    def predict_mastery_probability(
        self,
        quiz_score_avg: float,
        study_duration_hrs: float,
        session_count: int,
        topic_difficulty: float,
        completion_rate: float,
        recent_quiz_score: float,
        revision_frequency: int
    ) -> Dict[str, Any]:
        """
        Predicts probability of topic mastery.
        """
        features = np.array([[
            quiz_score_avg,
            study_duration_hrs,
            session_count,
            topic_difficulty,
            completion_rate,
            recent_quiz_score,
            revision_frequency
        ]])

        if self.model and hasattr(self.model, "predict_proba"):
            try:
                prob = float(self.model.predict_proba(features)[0][1])
            except Exception as e:
                logger.error(f"Inference error: {e}")
                prob = self._heuristic_prob(quiz_score_avg, completion_rate, recent_quiz_score, topic_difficulty)
        else:
            prob = self._heuristic_prob(quiz_score_avg, completion_rate, recent_quiz_score, topic_difficulty)

        prob = round(max(0.02, min(0.98, prob)), 3)
        is_likely = prob >= 0.70

        if prob < 0.45:
            recommendation = "High risk of forgetting: Add 2 remedial reviews with step-by-step flashcards."
            confidence = "High"
        elif prob < 0.70:
            recommendation = "Moderate mastery: Schedule 1 practice session focused on problem variants."
            confidence = "Medium"
        else:
            recommendation = "High mastery probability: Ready for exam simulation and advanced topics."
            confidence = "High"

        # Feature importances for explainability
        feature_importance_map = {
            "quiz_score_avg": 0.32,
            "recent_quiz_score": 0.26,
            "completion_rate": 0.18,
            "study_duration_hrs": 0.12,
            "revision_frequency": 0.08,
            "topic_difficulty": 0.04
        }

        return {
            "mastery_probability": prob,
            "is_mastery_likely": is_likely,
            "recommended_action": recommendation,
            "confidence_level": confidence,
            "feature_importances": feature_importance_map,
            "model_version": self.model_name
        }

    def _heuristic_prob(self, quiz_avg: float, completion: float, recent: float, difficulty: float) -> float:
        z = (0.35 * (quiz_avg / 100.0)) + (0.30 * (recent / 100.0)) + (0.25 * completion) - (0.20 * difficulty)
        # Sigmoid mapping centered around 0.5
        return float(1.0 / (1.0 + np.exp(-8.0 * (z - 0.48))))

mastery_predictor = MasteryPredictor()
