from datetime import datetime, timedelta, date
from typing import List, Dict, Any, Optional
import math

class SmartScheduler:
    """
    Constraint-based heuristic scheduling optimizer.
    Generates realistic, balanced, and explainable daily/weekly study schedules.
    """

    TIME_SLOTS = {
        "Morning": [("08:00", "09:00"), ("09:15", "10:15"), ("10:30", "11:30")],
        "Afternoon": [("14:00", "15:00"), ("15:15", "16:15"), ("16:30", "17:30")],
        "Evening": [("18:00", "19:00"), ("19:15", "20:15"), ("20:30", "21:30")],
        "Night": [("21:00", "22:00"), ("22:15", "23:15"), ("23:30", "00:30")]
    }

    @classmethod
    def generate_schedule(
        cls,
        topics_data: List[Dict[str, Any]],
        exams_data: List[Dict[str, Any]],
        start_date: Optional[date] = None,
        days_ahead: int = 14,
        available_hours_per_day: float = 3.0,
        preferred_time: str = "Evening",
        max_daily_study_time: float = 4.0
    ) -> List[Dict[str, Any]]:
        """
        Optimizes topic distribution across available days.
        """
        current_date = start_date or date.today()
        daily_slots_limit = min(int(math.floor(available_hours_per_day)), int(max_daily_study_time), 4)
        if daily_slots_limit < 1:
            daily_slots_limit = 1

        time_slots = cls.TIME_SLOTS.get(preferred_time, cls.TIME_SLOTS["Evening"])

        # Map exams by subject / topic to compute urgency
        exam_urgency_map = {}
        for exam in exams_data:
            exam_dt = exam.get("exam_date")
            if isinstance(exam_dt, str):
                try:
                    exam_dt = datetime.fromisoformat(exam_dt.replace("Z", "+00:00")).date()
                except Exception:
                    exam_dt = current_date + timedelta(days=20)
            elif isinstance(exam_dt, datetime):
                exam_dt = exam_dt.date()
            
            days_until = (exam_dt - current_date).days if exam_dt else 20
            subj_id = exam.get("subject_id")
            if subj_id:
                exam_urgency_map[subj_id] = max(1, days_until)

        # Score and rank topics for scheduling priority
        # Urgency formula:
        # Score = (1.0 - mastery) * 0.45 + (priority * 0.3) + (difficulty * 0.15) + (exam_urgency_factor * 0.1)
        scored_topics = []
        for t in topics_data:
            mastery = t.get("mastery_score", 0.2)
            priority = t.get("priority", 0.7)
            difficulty = t.get("difficulty", 0.5)
            subj_id = t.get("subject_id")
            
            days_to_exam = exam_urgency_map.get(subj_id, 20)
            exam_factor = max(0.1, 1.0 - (days_to_exam / 30.0))

            weight = ((1.0 - mastery) * 0.45) + (priority * 0.30) + (difficulty * 0.15) + (exam_factor * 0.10)
            scored_topics.append({
                **t,
                "scheduling_weight": weight,
                "days_to_exam": days_to_exam,
                "needs_revision": mastery < 0.60 or t.get("is_remedial", False)
            })

        # Sort descending by priority weight
        scored_topics.sort(key=lambda x: x["scheduling_weight"], reverse=True)

        scheduled_tasks = []
        topic_cursor = 0
        total_topics = len(scored_topics)

        if total_topics == 0:
            return []

        for day_offset in range(days_ahead):
            sched_date = current_date + timedelta(days=day_offset)
            date_str = sched_date.strftime("%Y-%m-%d")

            for slot_idx in range(daily_slots_limit):
                # Pick topic
                topic = scored_topics[topic_cursor % total_topics]
                topic_cursor += 1

                slot = time_slots[slot_idx % len(time_slots)]
                start_time, end_time = slot

                # Determine task type
                mastery = topic.get("mastery_score", 0.2)
                is_remedial = topic.get("is_remedial", False)

                if is_remedial or mastery < 0.50:
                    task_type = "REVISION" if topic.get("study_count", 0) > 0 else "LEARNING"
                    priority_level = "High"
                    reason = (
                        f"Low mastery ({int(mastery * 100)}%) + "
                        f"exam in {topic.get('days_to_exam', 20)} days. "
                        f"Allocated focus session with practice exercises."
                    )
                elif 0.50 <= mastery < 0.75:
                    task_type = "PRACTICE"
                    priority_level = "Medium"
                    reason = (
                        f"Moderate mastery ({int(mastery * 100)}%). "
                        f"Scheduled targeted problem-solving to reinforce retention."
                    )
                else:
                    task_type = "REVISION"
                    priority_level = "Low"
                    reason = (
                        f"High mastery ({int(mastery * 100)}%). "
                        f"Spaced repetition maintenance review before upcoming exams."
                    )

                tid = topic.get("id") or topic.get("name", "topic")
                scheduled_tasks.append({
                    "topic_id": tid,
                    "title": f"{topic['name']} - {task_type.capitalize()}",
                    "scheduled_date": date_str,
                    "start_time": start_time,
                    "end_time": end_time,
                    "duration_minutes": 60,
                    "task_type": task_type,
                    "priority": priority_level,
                    "is_remedial": is_remedial,
                    "reason": reason,
                    "topic_info": {
                        "id": tid,
                        "name": topic.get("name", "Topic"),
                        "subject_name": topic.get("subject_name", "General"),
                        "difficulty": topic.get("difficulty", 0.5),
                        "priority": topic.get("priority", 0.7)
                    }
                })

        return scheduled_tasks
