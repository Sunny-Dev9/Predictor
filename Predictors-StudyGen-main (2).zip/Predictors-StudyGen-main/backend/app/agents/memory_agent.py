import logging
from typing import Dict, Any
from app.agents.state import LearnerGraphState

logger = logging.getLogger(__name__)

class MemoryAgent:
    """
    Agent 7: Learner Memory Agent.
    Maintains persistent memory about learner habits, strengths, weaknesses,
    and preferences without storing sensitive data.
    """

    @classmethod
    async def run(cls, state: LearnerGraphState) -> Dict[str, Any]:
        logger.info("[MemoryAgent] Updating persistent learner memory...")
        current_memory = state.get("learner_memory", {})
        remedial = state.get("remedial_topics", [])
        advanced = state.get("advanced_topics", [])
        pref_time = state.get("preferred_study_time", "Evening")

        updated_memory = dict(current_memory)
        updated_memory["preferred_study_time"] = pref_time
        updated_memory["weak_topics"] = list(set(updated_memory.get("weak_topics", []) + remedial))
        updated_memory["mastered_topics"] = list(set(updated_memory.get("mastered_topics", []) + advanced))
        
        # Remove topics from weak if they are now in mastered
        updated_memory["weak_topics"] = [
            t for t in updated_memory["weak_topics"] if t not in updated_memory["mastered_topics"]
        ]

        return {
            "learner_memory": updated_memory,
            "agent_logs": [{
                "agent": "MemoryAgent",
                "action": "Updated persistent memory profile",
                "weak_count": len(updated_memory["weak_topics"]),
                "strong_count": len(updated_memory["mastered_topics"])
            }]
        }
