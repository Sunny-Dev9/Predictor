import logging
from typing import Dict, Any
from app.agents.state import LearnerGraphState
from app.services.llm import get_llm_provider

logger = logging.getLogger(__name__)

class SyllabusAnalyzerAgent:
    """
    Agent 1: Parses raw syllabus, extracts subjects/topics, estimates difficulty,
    and structures the learning graph with prerequisites.
    """

    @classmethod
    async def run(cls, state: LearnerGraphState) -> Dict[str, Any]:
        logger.info("[SyllabusAnalyzerAgent] Analyzing syllabus...")
        subject_name = state.get("subject_name", "Computer Science")
        raw_syllabus = state.get("raw_syllabus", "")

        prompt = (
            f"Analyze the following syllabus for subject: {subject_name}\n\n"
            f"Raw Syllabus Text:\n{raw_syllabus}\n\n"
            f"Task:\n"
            f"1. Break the subject into key learning topics and subtopics.\n"
            f"2. Assign each topic difficulty (0.1 to 1.0) and priority (0.1 to 1.0).\n"
            f"3. Estimate study hours required.\n"
            f"4. Identify prerequisite order between topics for a structured learning graph.\n"
            f"Output JSON with keys: 'subject_name', 'total_topics', 'total_estimated_hours', "
            f"'topics': [{{'name', 'description', 'difficulty', 'priority', 'estimated_hours', 'subtopics', 'prerequisites'}}], "
            f"'analysis_notes'."
        )

        llm = get_llm_provider()
        response_json = await llm.generate_json(prompt, system="You are an expert academic curriculum designer.")

        topics = response_json.get("topics", [])
        # Build learning graph edges
        edges = []
        for i in range(len(topics) - 1):
            edges.append({
                "source": topics[i]["name"],
                "target": topics[i + 1]["name"],
                "type": "prerequisite"
            })

        return {
            "topics": topics,
            "learning_graph_edges": edges,
            "agent_logs": [{
                "agent": "SyllabusAnalyzerAgent",
                "action": "Parsed syllabus into learning graph",
                "total_topics_found": len(topics),
                "notes": response_json.get("analysis_notes", "")
            }]
        }
