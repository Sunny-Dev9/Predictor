import logging
from typing import Dict, Any
from app.agents.state import LearnerGraphState
from app.services.mastery import MasteryEngine

logger = logging.getLogger(__name__)

class PerformanceAgent:
    """
    Agent 5: Evaluates quiz submissions, calculates composite topic mastery,
    and flags topics requiring remedial review or replanning.
    """

    @classmethod
    async def run(cls, state: LearnerGraphState) -> Dict[str, Any]:
        logger.info("[PerformanceAgent] Evaluating student performance...")
        quiz_score = state.get("quiz_score", 50.0)
        topic_id = state.get("active_topic_id", "default_topic")
        previous_mastery = state.get("mastery_updates", {}).get("mastery_score", 0.5)

        evaluation = MasteryEngine.evaluate_quiz_and_adapt(
            quiz_score_pct=quiz_score,
            previous_mastery=previous_mastery,
            study_count=1
        )

        replan_needed = evaluation["replan_required"]
        remedial_topics = state.get("remedial_topics", [])
        advanced_topics = state.get("advanced_topics", [])

        # Resolve topic name
        topic_name = topic_id
        for t in state.get("topics", []):
            if t.get("id") == topic_id or t.get("name") == topic_id:
                topic_name = t.get("name", topic_id)
                break

        if evaluation["is_remedial"]:
            for identifier in [topic_id, topic_name]:
                if identifier and identifier not in remedial_topics:
                    remedial_topics.append(identifier)
        elif quiz_score >= 80.0:
            for identifier in [topic_id, topic_name]:
                if identifier and identifier not in advanced_topics:
                    advanced_topics.append(identifier)

        replan_reason = None
        if replan_needed:
            replan_reason = f"Quiz score ({quiz_score}%) indicates weak mastery. Dynamic revision required."

        return {
            "mastery_updates": evaluation,
            "replan_needed": replan_needed,
            "replan_reason": replan_reason,
            "remedial_topics": remedial_topics,
            "advanced_topics": advanced_topics,
            "agent_logs": [{
                "agent": "PerformanceAgent",
                "action": "Evaluated mastery",
                "score": quiz_score,
                "new_mastery": evaluation["mastery_score"],
                "replan_triggered": replan_needed
            }]
        }
