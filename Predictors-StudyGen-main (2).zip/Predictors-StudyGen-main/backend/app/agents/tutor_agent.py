import logging
from typing import Dict, Any
from app.agents.state import LearnerGraphState
from app.rag.rag_service import rag_service
from app.services.llm import get_llm_provider

logger = logging.getLogger(__name__)

class TutorRAGAgent:
    """
    Agent 3: Tutor RAG Agent.
    Answers student questions grounded strictly in uploaded study notes, PDFs, and textbooks.
    Provides verifiable citations (filename, page number, similarity score).
    """

    @classmethod
    async def run(cls, state: LearnerGraphState) -> Dict[str, Any]:
        logger.info("[TutorRAGAgent] Processing learner question with RAG...")
        query = state.get("query_text", "")
        user_id = state.get("user_id")

        # Retrieve nearest grounded chunks
        chunks = await rag_service.retrieve_context(query=query, user_id=user_id, top_k=3)

        context_text = ""
        citations = []
        for c in chunks:
            citations.append({
                "document_id": c.get("document_id", ""),
                "document_name": c.get("filename", "Uploaded Notes"),
                "page_number": c.get("page_number", 1),
                "snippet": c.get("content", "")[:200] + "...",
                "relevance_score": round(float(c.get("score", 0.9)), 3)
            })
            context_text += f"\n--- Source: {c.get('filename')} (Page {c.get('page_number')}) ---\n{c.get('content')}\n"

        prompt = (
            f"You are the StudyGen AI Tutor. Answer the student's question accurately, "
            f"grounding your response in the provided study material excerpt.\n\n"
            f"Retrieved Study Material:\n{context_text if context_text else 'Course notes on Data Structures and Algorithms.'}\n\n"
            f"Student Question: {query}\n\n"
            f"Instructions:\n"
            f"- Explain clearly with intuitive concepts, time/space complexity, and code/bullet points if relevant.\n"
            f"- Reference the study material pages.\n"
            f"- If the material doesn't specify something, clearly state it."
        )

        llm = get_llm_provider()
        answer = await llm.generate_text(prompt, system="You are an empathetic, world-class academic tutor.")

        return {
            "tutor_answer": answer,
            "citations": citations,
            "agent_logs": [{
                "agent": "TutorRAGAgent",
                "action": "Answered student question with RAG citations",
                "citations_count": len(citations),
                "query": query
            }]
        }
