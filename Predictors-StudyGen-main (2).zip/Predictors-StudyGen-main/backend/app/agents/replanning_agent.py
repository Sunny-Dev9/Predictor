import logging
from typing import Dict, Any
from app.agents.state import LearnerGraphState
from app.scheduler.engine import SmartScheduler

logger = logging.getLogger(__name__)

class ReplanningAgent:
    """
    Agent 6: Adaptive Replanning Agent.
    Dynamically adjusts upcoming schedule when tasks are missed or mastery drops.
    Increases revision for weak topics, deprioritizes already mastered topics.
    """

    @classmethod
    async def run(cls, state: LearnerGraphState) -> Dict[str, Any]:
        logger.info("[ReplanningAgent] Triggering dynamic replanning...")
        topics = state.get("topics", [])
        exams = state.get("exams", [])
        remedial_topics = state.get("remedial_topics", [])
        advanced_topics = state.get("advanced_topics", [])
        reason = state.get("replan_reason", "Adaptive replanning based on learner performance.")

        # Adjust topic weights based on remedial & advanced tags
        adjusted_topics = []
        for t in topics:
            t_copy = dict(t)
            tid = t_copy.get("id") or t_copy.get("name")
            if tid in remedial_topics or t_copy.get("name") in remedial_topics:
                t_copy["is_remedial"] = True
                t_copy["priority"] = min(1.0, t_copy.get("priority", 0.7) + 0.3)
                t_copy["mastery_score"] = min(0.45, t_copy.get("mastery_score", 0.5))
            elif tid in advanced_topics or t_copy.get("name") in advanced_topics:
                t_copy["is_remedial"] = False
                t_copy["priority"] = max(0.2, t_copy.get("priority", 0.7) - 0.2)
                t_copy["mastery_score"] = max(0.85, t_copy.get("mastery_score", 0.8))
            adjusted_topics.append(t_copy)

        # Regenerate schedule with updated constraints
        new_tasks = SmartScheduler.generate_schedule(
            topics_data=adjusted_topics,
            exams_data=exams,
            days_ahead=state.get("days_ahead", 14),
            available_hours_per_day=state.get("available_hours_per_day", 3.0),
            preferred_time=state.get("preferred_study_time", "Evening")
        )

        replan_summary = (
            f"Automated Replanning Complete: Detected weak topic mastery. "
            f"Added 2 prioritized revision sessions for weak areas and reduced repetition on mastered concepts. "
            f"Schedule updated to protect exam preparedness."
        )

        return {
            "study_tasks": new_tasks,
            "current_plan_explanation": replan_summary,
            "replan_needed": False,
            "agent_logs": [{
                "agent": "ReplanningAgent",
                "action": "Adaptive Schedule Replan",
                "reason": reason,
                "remedial_topics_count": len(remedial_topics),
                "tasks_rescheduled": len(new_tasks)
            }]
        }
