import logging
from typing import Dict, Any
from langgraph.graph import StateGraph, END
from app.agents.state import LearnerGraphState
from app.agents.syllabus_agent import SyllabusAnalyzerAgent
from app.agents.planning_agent import PlanningAgent
from app.agents.quiz_agent import QuizAgent
from app.agents.performance_agent import PerformanceAgent
from app.agents.replanning_agent import ReplanningAgent
from app.agents.tutor_agent import TutorRAGAgent
from app.agents.memory_agent import MemoryAgent

logger = logging.getLogger(__name__)

# Router condition after performance evaluation
def should_replan_condition(state: LearnerGraphState) -> str:
    """
    Conditional routing in LangGraph:
    If quiz score < 50 or replan flag set, route to ReplanningAgent, else to MemoryAgent.
    """
    if state.get("replan_needed", False):
        return "replanning"
    return "memory"

def build_learner_graph():
    """
    Constructs the end-to-end LangGraph multi-agent loop:
    PLAN → LEARN → MEASURE → REMEMBER → ADAPT → REPLAN
    """
    workflow = StateGraph(LearnerGraphState)

    # Register agent nodes
    workflow.add_node("syllabus_analyzer", SyllabusAnalyzerAgent.run)
    workflow.add_node("planner", PlanningAgent.run)
    workflow.add_node("quiz", QuizAgent.run)
    workflow.add_node("performance", PerformanceAgent.run)
    workflow.add_node("memory", MemoryAgent.run)
    workflow.add_node("replanning", ReplanningAgent.run)
    workflow.add_node("tutor", TutorRAGAgent.run)

    # Normal entry routing or action dispatcher
    def route_entry(state: LearnerGraphState) -> str:
        trigger = state.get("action_trigger", "generate_plan")
        if trigger == "analyze_syllabus":
            return "syllabus_analyzer"
        elif trigger == "generate_plan":
            return "planner"
        elif trigger == "take_quiz":
            return "quiz"
        elif trigger == "evaluate_performance":
            return "performance"
        elif trigger == "replan":
            return "replanning"
        elif trigger == "tutor_query":
            return "tutor"
        return "planner"

    workflow.set_conditional_entry_point(
        route_entry,
        {
            "syllabus_analyzer": "syllabus_analyzer",
            "planner": "planner",
            "quiz": "quiz",
            "performance": "performance",
            "replanning": "replanning",
            "tutor": "tutor"
        }
    )

    # Syllabus flow connects to Planner
    workflow.add_edge("syllabus_analyzer", "planner")
    workflow.add_edge("planner", END)

    # Quiz flow connects to Performance evaluation
    workflow.add_edge("quiz", END)
    
    # Performance flow conditionally routes to Replanning or directly to Memory
    workflow.add_conditional_edges(
        "performance",
        should_replan_condition,
        {
            "replanning": "replanning",
            "memory": "memory"
        }
    )

    # Replanning updates memory then completes
    workflow.add_edge("replanning", "memory")
    workflow.add_edge("memory", END)

    # Tutor finishes after answering
    workflow.add_edge("tutor", END)

    return workflow.compile()

# Global compiled LangGraph application
learner_graph_app = build_learner_graph()
