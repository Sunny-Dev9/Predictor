import logging
from typing import Dict, Any
from app.agents.state import LearnerGraphState
from app.services.llm import get_llm_provider

logger = logging.getLogger(__name__)

class QuizAgent:
    """
    Agent 4: Generates diagnostic and practice quizzes from syllabus topics and uploaded notes.
    """

    @classmethod
    async def run(cls, state: LearnerGraphState) -> Dict[str, Any]:
        logger.info("[QuizAgent] Generating diagnostic quiz...")
        topic_name = state.get("active_topic_id", "Data Structures")
        # Check if full topic dict is present
        for t in state.get("topics", []):
            if t.get("id") == topic_name or t.get("name") == topic_name:
                topic_name = t.get("name")
                break

        prompt = (
            f"Generate an academic assessment quiz for topic: '{topic_name}'.\n"
            f"Requirements:\n"
            f"- 4 challenging conceptual questions (MCQs)\n"
            f"- 4 distinct choices per MCQ\n"
            f"- 1 clear correct answer\n"
            f"- In-depth explanation of why the answer is correct and why other options are incorrect.\n"
            f"Format strictly as JSON with key 'questions': list of {{'question_text', 'question_type', 'options', 'correct_answer', 'explanation'}}."
        )

        llm = get_llm_provider()
        quiz_data = await llm.generate_json(prompt, system="You are an expert university examiner.")

        return {
            "generated_quiz": quiz_data,
            "agent_logs": [{
                "agent": "QuizAgent",
                "action": "Generated quiz",
                "topic": topic_name,
                "question_count": len(quiz_data.get("questions", []))
            }]
        }
