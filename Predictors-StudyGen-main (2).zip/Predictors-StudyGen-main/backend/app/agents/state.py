from typing import List, Dict, Any, Optional, TypedDict, Annotated
import operator

class LearnerGraphState(TypedDict):
    """
    Shared LangGraph State across the 7 specialized agents:
    PLAN → LEARN → MEASURE → REMEMBER → ADAPT → REPLAN
    """
    user_id: str
    action_trigger: str # "analyze_syllabus", "generate_plan", "take_quiz", "evaluate_performance", "replan", "tutor_query"
    
    # Syllabus & Learning Graph
    raw_syllabus: Optional[str]
    subject_name: Optional[str]
    topics: List[Dict[str, Any]]
    exams: List[Dict[str, Any]]
    learning_graph_edges: List[Dict[str, Any]]
    
    # Planning & Scheduling
    available_hours_per_day: float
    preferred_study_time: str
    days_ahead: int
    study_tasks: List[Dict[str, Any]]
    current_plan_explanation: Optional[str]
    
    # Quiz & Performance
    active_topic_id: Optional[str]
    generated_quiz: Optional[Dict[str, Any]]
    quiz_submission: Optional[Dict[str, Any]]
    quiz_score: Optional[float]
    mastery_updates: Dict[str, Any]
    
    # Replanning & Adaptation
    replan_needed: bool
    replan_reason: Optional[str]
    remedial_topics: List[str]
    advanced_topics: List[str]
    
    # Tutor & RAG
    query_text: Optional[str]
    retrieved_chunks: List[Dict[str, Any]]
    tutor_answer: Optional[str]
    citations: List[Dict[str, Any]]
    
    # Memory & Audit
    learner_memory: Dict[str, Any]
    agent_logs: Annotated[List[Dict[str, Any]], operator.add]
    error: Optional[str]
