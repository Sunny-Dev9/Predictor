import logging
from typing import Dict, Any
from app.agents.state import LearnerGraphState
from app.scheduler.engine import SmartScheduler

logger = logging.getLogger(__name__)

class PlanningAgent:
    """
    Agent 2: Generates optimized daily/weekly study plans based on learner goals,
    exam dates, available hours, and topic mastery.
    """

    @classmethod
    async def run(cls, state: LearnerGraphState) -> Dict[str, Any]:
        logger.info("[PlanningAgent] Generating study schedule...")
        topics = state.get("topics", [])
        exams = state.get("exams", [])
        available_hours = state.get("available_hours_per_day", 3.0)
        preferred_time = state.get("preferred_study_time", "Evening")
        days_ahead = state.get("days_ahead", 14)

        scheduled_tasks = SmartScheduler.generate_schedule(
            topics_data=topics,
            exams_data=exams,
            days_ahead=days_ahead,
            available_hours_per_day=available_hours,
            preferred_time=preferred_time
        )

        total_hours = sum(t.get("duration_minutes", 60) for t in scheduled_tasks) / 60.0

        explanation = (
            f"Generated an adaptive {days_ahead}-day study plan comprising {len(scheduled_tasks)} sessions "
            f"({total_hours:.1f} total hours). Prioritized upcoming exam deadlines and weak mastery areas, "
            f"scheduling high-focus sessions during your preferred {preferred_time} window with regular spaced breaks."
        )

        return {
            "study_tasks": scheduled_tasks,
            "current_plan_explanation": explanation,
            "agent_logs": [{
                "agent": "PlanningAgent",
                "action": "Generated schedule",
                "task_count": len(scheduled_tasks),
                "total_hours": total_hours,
                "preferred_time": preferred_time
            }]
        }
