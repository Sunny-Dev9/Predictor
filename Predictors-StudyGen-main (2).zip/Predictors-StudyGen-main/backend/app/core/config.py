from typing import List, Optional
from pydantic_settings import BaseSettings
from pydantic import Field
import os

class Settings(BaseSettings):
    PROJECT_NAME: str = "StudyGen — Agentic AI Study Planner"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: str = "development"

    # Security
    SECRET_KEY: str = "studygen-super-secret-dev-key-for-hackathon-2026"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days

    # Database
    DATABASE_URL: str = Field(default="sqlite+aiosqlite:///./studygen.db")
    
    # Vector DB
    QDRANT_URL: str = ":memory:"
    QDRANT_API_KEY: Optional[str] = None
    QDRANT_COLLECTION: str = "studygen_notes"

    # LLM Settings
    DEFAULT_LLM_PROVIDER: str = "mock"  # 'mock', 'openai', or 'gemini'
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4o-mini"
    GEMINI_API_KEY: Optional[str] = None
    GEMINI_MODEL: str = "gemini-1.5-flash"

    # Redis / Celery
    REDIS_URL: str = "redis://localhost:6379/0"

    # MLOps
    MLFLOW_TRACKING_URI: str = "sqlite:///mlflow.db"
    MLFLOW_EXPERIMENT_NAME: str = "studygen_mastery_predictor"

    # Uploads
    UPLOAD_DIR: str = os.path.join(os.getcwd(), "uploads")

    # CORS
    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "*"
    ]

    class Config:
        case_sensitive = True
        env_file = ".env"
        extra = "allow"

settings = Settings()
