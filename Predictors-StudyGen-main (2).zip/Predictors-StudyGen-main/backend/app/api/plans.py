from datetime import date, datetime, timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.models.user import User, Profile
from app.models.subject import Subject, Topic, Exam
from app.models.task import StudyTask
from app.models.mastery import TopicMastery
from app.models.memory import AgentRun
from app.schemas.task import PlanGenerateRequest, PlanResponse, TaskResponse, ReplanRequest, TaskTopicInfo
from app.agents.graph import learner_graph_app
from app.api.deps import get_current_user

router = APIRouter(prefix="/plans", tags=["Planning & Replanning Agents"])

@router.post("/generate", response_model=PlanResponse)
async def generate_plan(
    request: PlanGenerateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Fetch profile
    prof_res = await db.execute(select(Profile).where(Profile.user_id == current_user.id))
    profile = prof_res.scalars().first()
    avail_hours = request.daily_available_hours or (profile.available_hours_per_day if profile else 3.0)
    pref_time = request.preferred_study_time or (profile.preferred_study_time if profile else "Evening")

    # Fetch all user topics with subject info and mastery
    topics_res = await db.execute(
        select(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .where(Subject.user_id == current_user.id)
        .options(selectinload(Topic.subject), selectinload(Topic.mastery))
    )
    topics = topics_res.scalars().all()

    if not topics:
        raise HTTPException(
            status_code=400,
            detail="No topics found. Please add subjects and topics or analyze a syllabus first."
        )

    # Fetch user exams
    exams_res = await db.execute(select(Exam).where(Exam.user_id == current_user.id))
    exams = exams_res.scalars().all()

    # Convert to agent state dictionaries
    topics_data = []
    for t in topics:
        mastery_score = t.mastery.mastery_score if t.mastery else 0.2
        is_remedial = (t.mastery.quiz_score < 50.0) if (t.mastery and t.mastery.quiz_score > 0) else False
        topics_data.append({
            "id": t.id,
            "name": t.name,
            "subject_id": t.subject_id,
            "subject_name": t.subject.name if t.subject else "General",
            "difficulty": t.difficulty,
            "priority": t.priority,
            "mastery_score": mastery_score,
            "is_remedial": is_remedial,
            "study_count": t.mastery.study_count if t.mastery else 0
        })

    exams_data = [
        {"name": e.name, "exam_date": e.exam_date, "subject_id": e.subject_id}
        for e in exams
    ]

    # LangGraph State
    state = {
        "user_id": current_user.id,
        "action_trigger": "generate_plan",
        "raw_syllabus": None,
        "subject_name": None,
        "topics": topics_data,
        "exams": exams_data,
        "learning_graph_edges": [],
        "available_hours_per_day": avail_hours,
        "preferred_study_time": pref_time,
        "days_ahead": request.days_ahead,
        "study_tasks": [],
        "current_plan_explanation": None,
        "active_topic_id": None,
        "generated_quiz": None,
        "quiz_submission": None,
        "quiz_score": None,
        "mastery_updates": {},
        "replan_needed": False,
        "replan_reason": None,
        "remedial_topics": [],
        "advanced_topics": [],
        "query_text": None,
        "retrieved_chunks": [],
        "tutor_answer": None,
        "citations": [],
        "learner_memory": {},
        "agent_logs": [],
        "error": None
    }

    graph_result = await learner_graph_app.ainvoke(state)
    new_tasks = graph_result.get("study_tasks", [])
    explanation = graph_result.get("current_plan_explanation", "Smart study plan generated.")

    # Remove pending future tasks to replace with new plan
    today_str = date.today().strftime("%Y-%m-%d")
    existing_tasks_res = await db.execute(
        select(StudyTask).where(
            StudyTask.user_id == current_user.id,
            StudyTask.status == "PENDING",
            StudyTask.scheduled_date >= today_str
        )
    )
    for old_t in existing_tasks_res.scalars().all():
        await db.delete(old_t)

    # Insert new scheduled tasks
    created_task_objs = []
    for t_item in new_tasks:
        db_task = StudyTask(
            user_id=current_user.id,
            topic_id=t_item["topic_id"],
            title=t_item["title"],
            scheduled_date=t_item["scheduled_date"],
            start_time=t_item.get("start_time", "18:00"),
            end_time=t_item.get("end_time", "19:00"),
            duration_minutes=t_item.get("duration_minutes", 60),
            task_type=t_item.get("task_type", "LEARNING"),
            priority=t_item.get("priority", "High"),
            reason=t_item.get("reason", "Scheduled based on exam proximity and topic mastery"),
            is_remedial=t_item.get("is_remedial", False),
            status="PENDING"
        )
        db.add(db_task)
        created_task_objs.append(db_task)

    # Log Agent Run
    agent_run = AgentRun(
        user_id=current_user.id,
        agent_name="PlanningAgent",
        trigger_event="generate_plan",
        input_payload={"days_ahead": request.days_ahead, "available_hours": avail_hours},
        output_summary=explanation,
        decisions_made={"task_count": len(new_tasks)}
    )
    db.add(agent_run)
    await db.commit()

    # Re-fetch tasks with topic and subject
    tasks_with_relations = await db.execute(
        select(StudyTask)
        .where(StudyTask.user_id == current_user.id, StudyTask.status == "PENDING")
        .options(selectinload(StudyTask.topic).selectinload(Topic.subject))
        .order_by(StudyTask.scheduled_date, StudyTask.start_time)
    )
    saved_tasks = tasks_with_relations.scalars().all()

    formatted_tasks = []
    for st in saved_tasks:
        topic_info = None
        if st.topic:
            topic_info = TaskTopicInfo(
                id=st.topic.id,
                name=st.topic.name,
                subject_name=st.topic.subject.name if st.topic.subject else None,
                difficulty=st.topic.difficulty,
                priority=st.topic.priority
            )
        formatted_tasks.append(
            TaskResponse(
                id=st.id,
                user_id=st.user_id,
                topic_id=st.topic_id,
                title=st.title,
                scheduled_date=st.scheduled_date,
                start_time=st.start_time,
                end_time=st.end_time,
                duration_minutes=st.duration_minutes,
                task_type=st.task_type,
                status=st.status,
                priority=st.priority,
                reason=st.reason,
                is_remedial=st.is_remedial,
                completed_at=st.completed_at,
                created_at=st.created_at,
                topic_info=topic_info
            )
        )

    start_d = formatted_tasks[0].scheduled_date if formatted_tasks else today_str
    end_d = formatted_tasks[-1].scheduled_date if formatted_tasks else today_str

    return PlanResponse(
        total_tasks=len(formatted_tasks),
        total_study_hours=round(sum(t.duration_minutes for t in formatted_tasks) / 60.0, 1),
        start_date=start_d,
        end_date=end_d,
        tasks=formatted_tasks,
        explanation=explanation
    )

@router.get("/current", response_model=List[TaskResponse])
async def get_current_plan(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    query = (
        select(StudyTask)
        .where(StudyTask.user_id == current_user.id)
        .options(selectinload(StudyTask.topic).selectinload(Topic.subject))
        .order_by(StudyTask.scheduled_date, StudyTask.start_time)
    )
    result = await db.execute(query)
    tasks = result.scalars().all()

    formatted_tasks = []
    for st in tasks:
        topic_info = None
        if st.topic:
            topic_info = TaskTopicInfo(
                id=st.topic.id,
                name=st.topic.name,
                subject_name=st.topic.subject.name if st.topic.subject else None,
                difficulty=st.topic.difficulty,
                priority=st.topic.priority
            )
        formatted_tasks.append(
            TaskResponse(
                id=st.id,
                user_id=st.user_id,
                topic_id=st.topic_id,
                title=st.title,
                scheduled_date=st.scheduled_date,
                start_time=st.start_time,
                end_time=st.end_time,
                duration_minutes=st.duration_minutes,
                task_type=st.task_type,
                status=st.status,
                priority=st.priority,
                reason=st.reason,
                is_remedial=st.is_remedial,
                completed_at=st.completed_at,
                created_at=st.created_at,
                topic_info=topic_info
            )
        )
    return formatted_tasks

@router.post("/replan", response_model=PlanResponse)
async def trigger_replan(
    replan_in: ReplanRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Invokes the ReplanningAgent in LangGraph to reorganize pending study tasks.
    """
    # Fetch topics and exams
    topics_res = await db.execute(
        select(Topic)
        .join(Subject, Topic.subject_id == Subject.id)
        .where(Subject.user_id == current_user.id)
        .options(selectinload(Topic.subject), selectinload(Topic.mastery))
    )
    topics = topics_res.scalars().all()

    remedial_topics = []
    topics_data = []
    for t in topics:
        m_score = t.mastery.mastery_score if t.mastery else 0.2
        is_rem = (m_score < 0.50) or (t.id == replan_in.triggered_topic_id)
        if is_rem:
            remedial_topics.append(t.id)
        topics_data.append({
            "id": t.id,
            "name": t.name,
            "subject_id": t.subject_id,
            "subject_name": t.subject.name if t.subject else "General",
            "difficulty": t.difficulty,
            "priority": t.priority,
            "mastery_score": m_score,
            "is_remedial": is_rem,
            "study_count": t.mastery.study_count if t.mastery else 0
        })

    exams_res = await db.execute(select(Exam).where(Exam.user_id == current_user.id))
    exams_data = [
        {"name": e.name, "exam_date": e.exam_date, "subject_id": e.subject_id}
        for e in exams_res.scalars().all()
    ]

    prof_res = await db.execute(select(Profile).where(Profile.user_id == current_user.id))
    profile = prof_res.scalars().first()

    state = {
        "user_id": current_user.id,
        "action_trigger": "replan",
        "raw_syllabus": None,
        "subject_name": None,
        "topics": topics_data,
        "exams": exams_data,
        "learning_graph_edges": [],
        "available_hours_per_day": profile.available_hours_per_day if profile else 3.0,
        "preferred_study_time": profile.preferred_study_time if profile else "Evening",
        "days_ahead": 14,
        "study_tasks": [],
        "current_plan_explanation": None,
        "active_topic_id": replan_in.triggered_topic_id,
        "generated_quiz": None,
        "quiz_submission": None,
        "quiz_score": None,
        "mastery_updates": {},
        "replan_needed": True,
        "replan_reason": replan_in.reason,
        "remedial_topics": remedial_topics,
        "advanced_topics": [],
        "query_text": None,
        "retrieved_chunks": [],
        "tutor_answer": None,
        "citations": [],
        "learner_memory": {},
        "agent_logs": [],
        "error": None
    }

    graph_result = await learner_graph_app.ainvoke(state)
    replanned_tasks = graph_result.get("study_tasks", [])
    explanation = graph_result.get("current_plan_explanation", "Adaptive replanning completed.")

    # Delete existing pending tasks and save new
    today_str = date.today().strftime("%Y-%m-%d")
    existing_tasks = await db.execute(
        select(StudyTask).where(
            StudyTask.user_id == current_user.id,
            StudyTask.status == "PENDING",
            StudyTask.scheduled_date >= today_str
        )
    )
    for old_t in existing_tasks.scalars().all():
        await db.delete(old_t)

    for t_item in replanned_tasks:
        db_task = StudyTask(
            user_id=current_user.id,
            topic_id=t_item["topic_id"],
            title=t_item["title"],
            scheduled_date=t_item["scheduled_date"],
            start_time=t_item.get("start_time", "18:00"),
            end_time=t_item.get("end_time", "19:00"),
            duration_minutes=t_item.get("duration_minutes", 60),
            task_type=t_item.get("task_type", "LEARNING"),
            priority=t_item.get("priority", "High"),
            reason=t_item.get("reason", "Rescheduled to prioritize weak topics"),
            is_remedial=t_item.get("is_remedial", False),
            status="PENDING"
        )
        db.add(db_task)

    agent_run = AgentRun(
        user_id=current_user.id,
        agent_name="ReplanningAgent",
        trigger_event="adaptive_replan",
        input_payload={"reason": replan_in.reason},
        output_summary=explanation,
        decisions_made={"rescheduled_tasks_count": len(replanned_tasks)}
    )
    db.add(agent_run)
    await db.commit()

    return await generate_plan(PlanGenerateRequest(days_ahead=14), current_user, db)
