import os
import shutil
import uuid
from typing import List
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from app.core.config import settings
from app.core.database import get_db
from app.models.user import User
from app.models.document import Document, DocumentChunk
from app.schemas.document import DocumentResponse, DocumentChunkResponse
from app.rag.rag_service import rag_service
from app.api.deps import get_current_user

router = APIRouter(prefix="/documents", tags=["Documents & RAG"])

@router.get("", response_model=List[DocumentResponse])
async def list_documents(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    query = (
        select(Document)
        .where(Document.user_id == current_user.id)
        .options(selectinload(Document.chunks))
        .order_by(Document.created_at.desc())
    )
    result = await db.execute(query)
    docs = result.scalars().all()
    
    resp = []
    for d in docs:
        resp.append(DocumentResponse(
            id=d.id,
            filename=d.filename,
            file_type=d.file_type,
            file_size=d.file_size,
            num_pages=d.num_pages,
            status=d.status,
            error_message=d.error_message,
            created_at=d.created_at,
            chunks_count=len(d.chunks)
        ))
    return resp

@router.post("/upload", response_model=DocumentResponse, status_code=status.HTTP_201_CREATED)
async def upload_document(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    doc_id = str(uuid.uuid4())
    ext = os.path.splitext(file.filename)[1].lower()
    
    file_type = "PDF"
    if ext in [".png", ".jpg", ".jpeg", ".webp"]:
        file_type = "IMAGE"
    elif ext in [".txt", ".md"]:
        file_type = "TEXT"

    saved_filename = f"{doc_id}_{file.filename}"
    saved_path = os.path.join(settings.UPLOAD_DIR, saved_filename)

    with open(saved_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    file_size = os.path.getsize(saved_path)

    # Create Document record
    db_doc = Document(
        id=doc_id,
        user_id=current_user.id,
        filename=file.filename,
        file_path=saved_path,
        file_type=file_type,
        file_size=file_size,
        status="PROCESSING"
    )
    db.add(db_doc)
    await db.commit()
    await db.refresh(db_doc)

    # Process and chunk asynchronously
    try:
        chunks = await rag_service.process_and_index_document(
            file_path=saved_path,
            document_id=doc_id,
            user_id=current_user.id,
            filename=file.filename,
            file_type=file_type
        )
        
        # Save chunks in DB
        for c in chunks:
            db_chunk = DocumentChunk(
                document_id=doc_id,
                content=c["content"],
                page_number=c["page_number"],
                chunk_index=c["chunk_index"],
                embedding_id=c.get("embedding_id")
            )
            db.add(db_chunk)

        db_doc.status = "PROCESSED"
        db_doc.num_pages = max([c["page_number"] for c in chunks], default=1)
        await db.commit()
        await db.refresh(db_doc)
    except Exception as e:
        db_doc.status = "FAILED"
        db_doc.error_message = str(e)
        await db.commit()
        await db.refresh(db_doc)

    return DocumentResponse(
        id=db_doc.id,
        filename=db_doc.filename,
        file_type=db_doc.file_type,
        file_size=db_doc.file_size,
        num_pages=db_doc.num_pages,
        status=db_doc.status,
        error_message=db_doc.error_message,
        created_at=db_doc.created_at,
        chunks_count=len(chunks) if db_doc.status == "PROCESSED" else 0
    )
