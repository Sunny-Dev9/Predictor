from fastapi import APIRouter
from app.api import (
    auth, profile, subjects, syllabus, plans,
    tasks, quiz, progress, documents, tutor, ml, demo
)

api_router = APIRouter()

api_router.include_router(auth.router)
api_router.include_router(profile.router)
api_router.include_router(subjects.router)
api_router.include_router(syllabus.router)
api_router.include_router(plans.router)
api_router.include_router(tasks.router)
api_router.include_router(quiz.router)
api_router.include_router(progress.router)
api_router.include_router(documents.router)
api_router.include_router(tutor.router)
api_router.include_router(ml.router)
api_router.include_router(demo.router)
