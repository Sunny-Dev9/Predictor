from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.models.user import User
from app.schemas.tutor import ChatRequest, ChatResponse, Citation
from app.agents.graph import learner_graph_app
from app.api.deps import get_current_user

router = APIRouter(prefix="/chat", tags=["AI Tutor & RAG Agent"])

@router.post("", response_model=ChatResponse)
async def chat_with_tutor(
    request: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # LangGraph State for Tutor Agent
    state = {
        "user_id": current_user.id,
        "action_trigger": "tutor_query",
        "raw_syllabus": None,
        "subject_name": None,
        "topics": [],
        "exams": [],
        "learning_graph_edges": [],
        "available_hours_per_day": 3.0,
        "preferred_study_time": "Evening",
        "days_ahead": 14,
        "study_tasks": [],
        "current_plan_explanation": None,
        "active_topic_id": request.topic_id,
        "generated_quiz": None,
        "quiz_submission": None,
        "quiz_score": None,
        "mastery_updates": {},
        "replan_needed": False,
        "replan_reason": None,
        "remedial_topics": [],
        "advanced_topics": [],
        "query_text": request.message,
        "retrieved_chunks": [],
        "tutor_answer": None,
        "citations": [],
        "learner_memory": {},
        "agent_logs": [],
        "error": None
    }

    graph_result = await learner_graph_app.ainvoke(state)
    answer = graph_result.get("tutor_answer", "Here is the explanation based on your notes.")
    raw_citations = graph_result.get("citations", [])

    citations = [
        Citation(
            document_id=c.get("document_id", "doc-1"),
            document_name=c.get("document_name", "DSA_Lecture_Notes.pdf"),
            page_number=c.get("page_number", 1),
            snippet=c.get("snippet", ""),
            relevance_score=c.get("relevance_score", 0.92)
        )
        for c in raw_citations
    ]

    # Smart follow-up recommendations
    follow_ups = [
        "How do Left-Right (LR) rotations work during AVL insertion?",
        "What is the difference between Red-Black Tree and AVL Tree balancing frequency?",
        "Generate a 3-question quiz on Binary Search Tree invariants."
    ]

    return ChatResponse(
        answer=answer,
        citations=citations,
        follow_up_questions=follow_ups,
        related_topic_id=request.topic_id
    )
