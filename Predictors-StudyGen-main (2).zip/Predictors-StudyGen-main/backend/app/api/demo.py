from datetime import datetime, timezone, timedelta, date
from fastapi import APIRouter, Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.core.database import get_db
from app.core.security import get_password_hash, create_access_token
from app.models.user import User, Profile
from app.models.subject import Subject, Topic, Subtopic, Exam
from app.models.mastery import TopicMastery
from app.models.task import StudyTask
from app.models.quiz import QuizAttempt, QuizQuestion
from app.models.document import Document, DocumentChunk
from app.models.memory import Memory
from app.rag.vector_store import vector_store
from app.scheduler.engine import SmartScheduler

router = APIRouter(prefix="/demo", tags=["Demo & Hackathon Scenario"])

@router.post("/seed", status_code=status.HTTP_200_OK)
async def seed_demo_data(db: AsyncSession = Depends(get_db)):
    """
    One-click setup for the official 10-step Hackathon Demo Scenario:
    1. Student with exams in 20 days, 3 hrs/day available.
    2. Subjects: DSA, DBMS, OS, ML.
    3. Binary Trees topic configured at 45% mastery.
    4. Uploaded DSA Notes on AVL Trees indexed in RAG.
    5. Adaptive replanning triggers ready.
    """
    email = "student@demo.studygen.ai"
    
    # 1. Clean existing demo user if exists
    res = await db.execute(select(User).where(User.email == email))
    existing_user = res.scalars().first()
    if existing_user:
        await db.delete(existing_user)
        await db.commit()

    # 2. Create Demo User
    now = datetime.now(timezone.utc)
    demo_user = User(
        email=email,
        hashed_password=get_password_hash("demopassword123"),
        full_name="Alex Rivera (CS Major)"
    )
    db.add(demo_user)
    await db.flush()

    # 3. Create Profile
    exam_date = now + timedelta(days=20)
    profile = Profile(
        user_id=demo_user.id,
        target_exam_name="Computer Science Semester Finals",
        exam_date=exam_date,
        available_hours_per_day=3.0,
        preferred_study_time="Evening",
        max_daily_study_time=4.0,
        learning_style="Visual & Problem Solving",
        onboarding_completed=True,
        streak_count=5,
        total_study_minutes=720
    )
    db.add(profile)

    # 4. Create Subjects
    subjects_info = [
        {"name": "Data Structures & Algorithms", "code": "CS201", "color": "#3B82F6"},
        {"name": "Database Management Systems", "code": "CS204", "color": "#10B981"},
        {"name": "Operating Systems", "code": "CS205", "color": "#F59E0B"},
        {"name": "Machine Learning", "code": "CS301", "color": "#8B5CF6"}
    ]

    created_subjects = []
    for s in subjects_info:
        sub = Subject(
            user_id=demo_user.id,
            name=s["name"],
            code=s["code"],
            color=s["color"],
            description=f"Core university curriculum module for {s['name']}."
        )
        db.add(sub)
        created_subjects.append(sub)
    await db.flush()

    dsa_subject = created_subjects[0]

    # 5. Create Exam
    exam = Exam(
        user_id=demo_user.id,
        subject_id=dsa_subject.id,
        name="DSA Final Exam",
        exam_date=exam_date,
        weightage=1.0,
        target_score=90.0
    )
    db.add(exam)

    # 6. Create DSA Topics with deliberate mastery levels (Binary Trees low mastery 45%)
    dsa_topics_data = [
        {
            "name": "Arrays & Strings",
            "desc": "Two pointers, sliding window, prefix sum",
            "diff": 0.3, "prio": 0.75, "hours": 3.0,
            "mastery": 0.85, "quiz": 88.0, "studied": now - timedelta(days=2),
            "subs": ["Two Pointers", "Sliding Window", "Prefix Sum"]
        },
        {
            "name": "Linked Lists",
            "desc": "Singly, doubly, cycle detection, reversal",
            "diff": 0.4, "prio": 0.70, "hours": 2.5,
            "mastery": 0.80, "quiz": 82.0, "studied": now - timedelta(days=3),
            "subs": ["Cycle Detection", "Reverse Sublist", "LRU Cache"]
        },
        {
            "name": "Stacks & Queues",
            "desc": "Monotonic stack, circular queue",
            "diff": 0.5, "prio": 0.70, "hours": 3.0,
            "mastery": 0.68, "quiz": 70.0, "studied": now - timedelta(days=4),
            "subs": ["Monotonic Stack", "Min Stack", "Deque"]
        },
        {
            "name": "Binary Trees & BST",
            "desc": "Tree traversals, AVL trees, LCA, tree balancing",
            "diff": 0.8, "prio": 0.95, "hours": 5.0,
            "mastery": 0.45, "quiz": 45.0, "studied": now - timedelta(days=1),
            "subs": ["Tree Traversals", "Lowest Common Ancestor", "AVL Rotations & Balancing"]
        },
        {
            "name": "Graph Algorithms",
            "desc": "BFS, DFS, Dijkstra, Topo Sort",
            "diff": 0.85, "prio": 0.90, "hours": 5.0,
            "mastery": 0.35, "quiz": 0.0, "studied": None,
            "subs": ["BFS / DFS", "Dijkstra Algorithm", "Topological Sort"]
        },
        {
            "name": "Dynamic Programming",
            "desc": "Knapsack, LCS, memoization patterns",
            "diff": 0.9, "prio": 0.85, "hours": 4.0,
            "mastery": 0.20, "quiz": 0.0, "studied": None,
            "subs": ["0/1 Knapsack", "Longest Common Subsequence", "Grid DP"]
        }
    ]

    created_topics = []
    for idx, td in enumerate(dsa_topics_data):
        topic = Topic(
            subject_id=dsa_subject.id,
            name=td["name"],
            description=td["desc"],
            difficulty=td["diff"],
            priority=td["prio"],
            estimated_hours=td["hours"],
            order_index=idx
        )
        db.add(topic)
        await db.flush()

        # Mastery record
        mastery = TopicMastery(
            topic_id=topic.id,
            user_id=demo_user.id,
            mastery_score=td["mastery"],
            difficulty=td["diff"],
            priority=td["prio"],
            last_studied=td["studied"],
            study_count=3 if td["studied"] else 0,
            quiz_score=td["quiz"],
            recent_performance=td["quiz"] / 100.0 if td["quiz"] > 0 else 0.0,
            completion_rate=0.75 if td["studied"] else 0.0,
            consistency_score=0.80,
            revision_due=now + timedelta(days=1) if td["mastery"] < 0.5 else now + timedelta(days=7)
        )
        db.add(mastery)

        for s_idx, s_name in enumerate(td["subs"]):
            sub = Subtopic(topic_id=topic.id, name=s_name, order_index=s_idx)
            db.add(sub)

        created_topics.append({
            "id": topic.id,
            "name": topic.name,
            "subject_id": dsa_subject.id,
            "subject_name": dsa_subject.name,
            "difficulty": td["diff"],
            "priority": td["prio"],
            "mastery_score": td["mastery"],
            "is_remedial": td["mastery"] < 0.50,
            "study_count": 3 if td["studied"] else 0
        })

    # 7. Generate Schedule via SmartScheduler
    scheduled_tasks = SmartScheduler.generate_schedule(
        topics_data=created_topics,
        exams_data=[{"name": exam.name, "exam_date": exam.exam_date, "subject_id": dsa_subject.id}],
        days_ahead=14,
        available_hours_per_day=3.0,
        preferred_time="Evening"
    )

    for st in scheduled_tasks:
        db_task = StudyTask(
            user_id=demo_user.id,
            topic_id=st["topic_id"],
            title=st["title"],
            scheduled_date=st["scheduled_date"],
            start_time=st.get("start_time", "18:00"),
            end_time=st.get("end_time", "19:00"),
            duration_minutes=st.get("duration_minutes", 60),
            task_type=st.get("task_type", "LEARNING"),
            priority=st.get("priority", "High"),
            reason=st.get("reason", "Scheduled based on low mastery and upcoming exam in 20 days"),
            is_remedial=st.get("is_remedial", False),
            status="PENDING"
        )
        db.add(db_task)

    # 8. Seed Demo PDF Note on AVL Trees & RAG Vectors
    binary_trees_topic = [t for t in created_topics if "Binary Trees" in t["name"]][0]
    
    doc = Document(
        user_id=demo_user.id,
        filename="DSA_Lecture_Notes_Trees_AVL.pdf",
        file_path="uploads/demo_dsa_notes.pdf",
        file_type="PDF",
        file_size=1024 * 340,
        num_pages=3,
        status="PROCESSED"
    )
    db.add(doc)
    await db.flush()

    chunks_text = [
        (1, "An AVL tree is a strictly height-balanced binary search tree. For every node, the height difference between the left and right subtrees (Balance Factor) must be in {-1, 0, +1}. If any node's balance factor exceeds this range after insertion or deletion, rotation operations are applied."),
        (2, "AVL Rotations: When a node becomes unbalanced, there are four rotation cases: 1. Left-Left (LL) - solved by single right rotation. 2. Right-Right (RR) - solved by single left rotation. 3. Left-Right (LR) - solved by left rotation on left child, then right rotation on unbalanced node. 4. Right-Left (RL) - solved by right rotation on right child, then left rotation."),
        (3, "Asymptotic Analysis: Because the AVL tree maintains a strictly logarithmic height h <= 1.44 log2(n), operations like search, minimum, maximum, insertion, and deletion all run in guaranteed worst-case O(log n) time. This prevents degeneration into an O(n) linked list.")
    ]

    for p_num, c_txt in chunks_text:
        d_chunk = DocumentChunk(
            document_id=doc.id,
            content=c_txt,
            page_number=p_num,
            chunk_index=p_num - 1
        )
        db.add(d_chunk)

    # Upsert into vector store for grounded RAG
    vector_store.upsert_chunks(
        vectors=[[0.1 * (i + 1)] * 128 for i in range(len(chunks_text))],
        payloads=[
            {
                "user_id": demo_user.id,
                "document_id": doc.id,
                "filename": doc.filename,
                "page_number": p,
                "content": c
            }
            for p, c in chunks_text
        ]
    )

    # 9. Seed Memory items
    db.add(Memory(
        user_id=demo_user.id,
        category="WEAK_TOPIC",
        key="Binary Trees & BST",
        value="Score 45% on diagnostic quiz. Struggles with AVL rotation conditions and tree balancing.",
        importance=0.9
    ))
    db.add(Memory(
        user_id=demo_user.id,
        category="STRONG_TOPIC",
        key="Arrays & Strings",
        value="Mastery 85%. Strong performance in two pointers and sliding window.",
        importance=0.7
    ))
    db.add(Memory(
        user_id=demo_user.id,
        category="PREFERENCE",
        key="Study Hours",
        value="Prefers 3 hours daily in the Evening slot (18:00 - 21:00) with 15-minute breaks.",
        importance=0.8
    ))

    await db.commit()

    # Generate token for instant demo login
    token = create_access_token(subject=demo_user.id)

    return {
        "status": "success",
        "message": "Demo data successfully seeded for Hackathon Scenario!",
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": demo_user.id,
            "email": demo_user.email,
            "full_name": demo_user.full_name
        },
        "scenario": {
            "exam_countdown_days": 20,
            "daily_hours": 3.0,
            "weak_topic": "Binary Trees & BST (45% mastery)",
            "rag_document": doc.filename,
            "tasks_scheduled": len(scheduled_tasks)
        }
    }
