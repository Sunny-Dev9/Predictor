from fastapi import APIRouter
from app.schemas.ml import MasteryPredictRequest, MasteryPredictResponse
from app.ml.predictor import mastery_predictor

router = APIRouter(prefix="/ml", tags=["ML Mastery Predictor"])

@router.post("/predict", response_model=MasteryPredictResponse)
async def predict_topic_mastery(request: MasteryPredictRequest):
    result = mastery_predictor.predict_mastery_probability(
        quiz_score_avg=request.quiz_score_avg,
        study_duration_hrs=request.study_duration_hrs,
        session_count=request.session_count,
        topic_difficulty=request.topic_difficulty,
        completion_rate=request.completion_rate,
        recent_quiz_score=request.recent_quiz_score,
        revision_frequency=request.revision_frequency
    )
    return MasteryPredictResponse(**result)
