from datetime import datetime, timezone
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.models.user import User
from app.models.subject import Topic
from app.models.quiz import QuizAttempt, QuizQuestion
from app.models.mastery import TopicMastery
from app.models.memory import AgentRun
from app.schemas.quiz import (
    QuizGenerateRequest, QuizSubmitRequest, QuizAttemptResponse, QuizQuestionResponse
)
from app.agents.graph import learner_graph_app
from app.api.deps import get_current_user
from app.api.plans import trigger_replan
from app.schemas.task import ReplanRequest

router = APIRouter(prefix="/quiz", tags=["Quiz & Performance Agents"])

@router.post("/generate", response_model=QuizAttemptResponse)
async def generate_quiz(
    request: QuizGenerateRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Verify topic
    topic_res = await db.execute(select(Topic).where(Topic.id == request.topic_id))
    topic = topic_res.scalars().first()
    if not topic:
        raise HTTPException(status_code=404, detail="Topic not found")

    # Run QuizAgent via LangGraph
    state = {
        "user_id": current_user.id,
        "action_trigger": "take_quiz",
        "raw_syllabus": None,
        "subject_name": None,
        "topics": [{"id": topic.id, "name": topic.name}],
        "exams": [],
        "learning_graph_edges": [],
        "available_hours_per_day": 3.0,
        "preferred_study_time": "Evening",
        "days_ahead": 14,
        "study_tasks": [],
        "current_plan_explanation": None,
        "active_topic_id": topic.id,
        "generated_quiz": None,
        "quiz_submission": None,
        "quiz_score": None,
        "mastery_updates": {},
        "replan_needed": False,
        "replan_reason": None,
        "remedial_topics": [],
        "advanced_topics": [],
        "query_text": None,
        "retrieved_chunks": [],
        "tutor_answer": None,
        "citations": [],
        "learner_memory": {},
        "agent_logs": [],
        "error": None
    }

    graph_result = await learner_graph_app.ainvoke(state)
    quiz_data = graph_result.get("generated_quiz", {})
    raw_questions = quiz_data.get("questions", [])

    # Create QuizAttempt
    attempt = QuizAttempt(
        user_id=current_user.id,
        topic_id=topic.id,
        total_questions=len(raw_questions),
        correct_answers=0,
        score_percentage=0.0
    )
    db.add(attempt)
    await db.flush()

    question_responses = []
    for q in raw_questions:
        qq = QuizQuestion(
            attempt_id=attempt.id,
            question_text=q["question_text"],
            question_type=q.get("question_type", "MCQ"),
            options=q.get("options", []),
            correct_answer=q["correct_answer"],
            explanation=q.get("explanation", "")
        )
        db.add(qq)
        await db.flush()
        question_responses.append(
            QuizQuestionResponse(
                id=qq.id,
                question_text=qq.question_text,
                question_type=qq.question_type,
                options=qq.options,
                student_answer=None,
                is_correct=None,
                explanation=None # Hidden before submission
            )
        )

    await db.commit()
    await db.refresh(attempt)

    return QuizAttemptResponse(
        id=attempt.id,
        topic_id=topic.id,
        topic_name=topic.name,
        total_questions=attempt.total_questions,
        correct_answers=0,
        score_percentage=0.0,
        feedback="Quiz generated. Ready to answer.",
        time_taken_seconds=0,
        created_at=attempt.created_at,
        questions=question_responses,
        replan_triggered=False,
        adaptive_recommendation=None
    )

@router.post("/submit", response_model=QuizAttemptResponse)
async def submit_quiz(
    submission: QuizSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Fetch attempt and questions
    att_res = await db.execute(
        select(QuizAttempt)
        .where(QuizAttempt.id == submission.attempt_id, QuizAttempt.user_id == current_user.id)
        .options(selectinload(QuizAttempt.questions))
    )
    attempt = att_res.scalars().first()
    if not attempt:
        raise HTTPException(status_code=404, detail="Quiz attempt not found")

    # Fetch topic
    top_res = await db.execute(select(Topic).where(Topic.id == attempt.topic_id))
    topic = top_res.scalars().first()
    topic_name = topic.name if topic else "Topic"

    # Evaluate answers
    answer_map = {ans.question_id: ans.student_answer.strip() for ans in submission.answers}
    correct_count = 0
    evaluated_questions = []

    for q in attempt.questions:
        student_ans = answer_map.get(q.id, "")
        q.student_answer = student_ans
        # Exact match or case-insensitive match
        is_corr = (student_ans.lower() == q.correct_answer.lower())
        q.is_correct = is_corr
        if is_corr:
            correct_count += 1

        evaluated_questions.append(
            QuizQuestionResponse(
                id=q.id,
                question_text=q.question_text,
                question_type=q.question_type,
                options=q.options,
                student_answer=student_ans,
                is_correct=is_corr,
                explanation=q.explanation
            )
        )

    score_pct = round((correct_count / max(1, attempt.total_questions)) * 100.0, 1)
    attempt.correct_answers = correct_count
    attempt.score_percentage = score_pct
    attempt.time_taken_seconds = submission.time_taken_seconds

    # Fetch previous mastery
    mast_res = await db.execute(select(TopicMastery).where(TopicMastery.topic_id == attempt.topic_id))
    mastery = mast_res.scalars().first()
    prev_mastery = mastery.mastery_score if mastery else 0.5

    # Run PerformanceAgent through LangGraph
    state = {
        "user_id": current_user.id,
        "action_trigger": "evaluate_performance",
        "raw_syllabus": None,
        "subject_name": None,
        "topics": [{"id": attempt.topic_id, "name": topic_name}],
        "exams": [],
        "learning_graph_edges": [],
        "available_hours_per_day": 3.0,
        "preferred_study_time": "Evening",
        "days_ahead": 14,
        "study_tasks": [],
        "current_plan_explanation": None,
        "active_topic_id": attempt.topic_id,
        "generated_quiz": None,
        "quiz_submission": submission.model_dump(),
        "quiz_score": score_pct,
        "mastery_updates": {"mastery_score": prev_mastery},
        "replan_needed": False,
        "replan_reason": None,
        "remedial_topics": [],
        "advanced_topics": [],
        "query_text": None,
        "retrieved_chunks": [],
        "tutor_answer": None,
        "citations": [],
        "learner_memory": {},
        "agent_logs": [],
        "error": None
    }

    graph_result = await learner_graph_app.ainvoke(state)
    eval_data = graph_result.get("mastery_updates", {})
    new_mastery_score = eval_data.get("mastery_score", prev_mastery)
    replan_triggered = graph_result.get("replan_needed", False)
    recommendation = eval_data.get("recommendation", "Quiz evaluated.")

    attempt.feedback = recommendation

    # Update Topic Mastery in DB
    if mastery:
        mastery.quiz_score = score_pct
        mastery.recent_performance = score_pct / 100.0
        mastery.mastery_score = new_mastery_score
        mastery.last_studied = datetime.now(timezone.utc)
        if eval_data.get("revision_due"):
            mastery.revision_due = eval_data["revision_due"]

    # Log Agent Run
    agent_run = AgentRun(
        user_id=current_user.id,
        agent_name="PerformanceAgent",
        trigger_event="quiz_submission",
        input_payload={"score_pct": score_pct, "topic": topic_name},
        output_summary=recommendation,
        decisions_made={"replan_triggered": replan_triggered, "new_mastery": new_mastery_score}
    )
    db.add(agent_run)
    await db.commit()

    # Trigger automatic replan if score < 50
    if replan_triggered:
        try:
            await trigger_replan(
                ReplanRequest(
                    reason=f"Quiz score on '{topic_name}' was {score_pct}%. Dynamic revision schedule initiated.",
                    triggered_topic_id=attempt.topic_id
                ),
                current_user=current_user,
                db=db
            )
        except Exception as e:
            pass

    return QuizAttemptResponse(
        id=attempt.id,
        topic_id=attempt.topic_id,
        topic_name=topic_name,
        total_questions=attempt.total_questions,
        correct_answers=attempt.correct_answers,
        score_percentage=attempt.score_percentage,
        feedback=attempt.feedback,
        time_taken_seconds=attempt.time_taken_seconds,
        created_at=attempt.created_at,
        questions=evaluated_questions,
        replan_triggered=replan_triggered,
        adaptive_recommendation=recommendation
    )
