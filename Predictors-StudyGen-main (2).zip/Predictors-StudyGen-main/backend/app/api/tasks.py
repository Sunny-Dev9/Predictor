from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.models.user import User, Profile
from app.models.task import StudyTask, StudySession
from app.models.mastery import TopicMastery
from app.models.subject import Topic
from app.schemas.task import TaskResponse, TaskUpdate, StudySessionCreate, TaskTopicInfo
from app.api.deps import get_current_user

router = APIRouter(prefix="/tasks", tags=["Study Tasks & Sessions"])

@router.post("/{task_id}/complete", response_model=TaskResponse)
async def complete_task(
    task_id: str,
    session_data: StudySessionCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    res = await db.execute(
        select(StudyTask)
        .where(StudyTask.id == task_id, StudyTask.user_id == current_user.id)
        .options(selectinload(StudyTask.topic).selectinload(Topic.subject))
    )
    task = res.scalars().first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    now = datetime.now(timezone.utc)
    task.status = "COMPLETED"
    task.completed_at = now

    # Record study session
    study_session = StudySession(
        user_id=current_user.id,
        task_id=task.id,
        duration_minutes=session_data.duration_minutes,
        focus_score=session_data.focus_score,
        notes=session_data.notes
    )
    db.add(study_session)

    # Update Profile streak & total minutes
    prof_res = await db.execute(select(Profile).where(Profile.user_id == current_user.id))
    profile = prof_res.scalars().first()
    if profile:
        profile.total_study_minutes += session_data.duration_minutes
        profile.streak_count += 1

    # Update Topic Mastery study count & last studied
    mastery_res = await db.execute(select(TopicMastery).where(TopicMastery.topic_id == task.topic_id))
    mastery = mastery_res.scalars().first()
    if mastery:
        mastery.study_count += 1
        mastery.last_studied = now
        mastery.completion_rate = min(1.0, mastery.completion_rate + 0.1)
        # Small boost in mastery from active completion
        mastery.mastery_score = min(1.0, mastery.mastery_score + 0.05)

    await db.commit()
    await db.refresh(task)

    topic_info = None
    if task.topic:
        topic_info = TaskTopicInfo(
            id=task.topic.id,
            name=task.topic.name,
            subject_name=task.topic.subject.name if task.topic.subject else None,
            difficulty=task.topic.difficulty,
            priority=task.topic.priority
        )

    return TaskResponse(
        id=task.id,
        user_id=task.user_id,
        topic_id=task.topic_id,
        title=task.title,
        scheduled_date=task.scheduled_date,
        start_time=task.start_time,
        end_time=task.end_time,
        duration_minutes=task.duration_minutes,
        task_type=task.task_type,
        status=task.status,
        priority=task.priority,
        reason=task.reason,
        is_remedial=task.is_remedial,
        completed_at=task.completed_at,
        created_at=task.created_at,
        topic_info=topic_info
    )

@router.post("/{task_id}/skip", response_model=TaskResponse)
async def skip_task(
    task_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    res = await db.execute(
        select(StudyTask)
        .where(StudyTask.id == task_id, StudyTask.user_id == current_user.id)
        .options(selectinload(StudyTask.topic).selectinload(Topic.subject))
    )
    task = res.scalars().first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    task.status = "SKIPPED"
    await db.commit()
    await db.refresh(task)

    topic_info = None
    if task.topic:
        topic_info = TaskTopicInfo(
            id=task.topic.id,
            name=task.topic.name,
            subject_name=task.topic.subject.name if task.topic.subject else None,
            difficulty=task.topic.difficulty,
            priority=task.topic.priority
        )

    return TaskResponse(
        id=task.id,
        user_id=task.user_id,
        topic_id=task.topic_id,
        title=task.title,
        scheduled_date=task.scheduled_date,
        start_time=task.start_time,
        end_time=task.end_time,
        duration_minutes=task.duration_minutes,
        task_type=task.task_type,
        status=task.status,
        priority=task.priority,
        reason=task.reason,
        is_remedial=task.is_remedial,
        completed_at=task.completed_at,
        created_at=task.created_at,
        topic_info=topic_info
    )
