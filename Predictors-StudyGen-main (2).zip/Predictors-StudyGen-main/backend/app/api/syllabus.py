from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.core.database import get_db
from app.models.user import User
from app.models.subject import Subject, Topic, Subtopic
from app.models.mastery import TopicMastery
from app.models.memory import AgentRun
from app.schemas.subject import SyllabusAnalyzeRequest, SyllabusAnalyzeResponse, AnalyzedTopicItem
from app.agents.graph import learner_graph_app
from app.api.deps import get_current_user

router = APIRouter(prefix="/syllabus", tags=["Syllabus Analyzer Agent"])

@router.post("/analyze", response_model=SyllabusAnalyzeResponse)
async def analyze_syllabus(
    request: SyllabusAnalyzeRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Prepare LangGraph state
    initial_state = {
        "user_id": current_user.id,
        "action_trigger": "analyze_syllabus",
        "subject_name": request.subject_name,
        "raw_syllabus": request.raw_syllabus_text,
        "topics": [],
        "exams": [],
        "learning_graph_edges": [],
        "available_hours_per_day": 3.0,
        "preferred_study_time": "Evening",
        "days_ahead": 14,
        "study_tasks": [],
        "current_plan_explanation": None,
        "active_topic_id": None,
        "generated_quiz": None,
        "quiz_submission": None,
        "quiz_score": None,
        "mastery_updates": {},
        "replan_needed": False,
        "replan_reason": None,
        "remedial_topics": [],
        "advanced_topics": [],
        "query_text": None,
        "retrieved_chunks": [],
        "tutor_answer": None,
        "citations": [],
        "learner_memory": {},
        "agent_logs": [],
        "error": None
    }

    # Execute LangGraph workflow
    graph_result = await learner_graph_app.ainvoke(initial_state)

    extracted_topics = graph_result.get("topics", [])
    graph_edges = graph_result.get("learning_graph_edges", [])

    # Find or create subject
    res = await db.execute(
        select(Subject).where(Subject.user_id == current_user.id, Subject.name == request.subject_name)
    )
    subject = res.scalars().first()
    if not subject:
        subject = Subject(
            user_id=current_user.id,
            name=request.subject_name,
            description=f"Auto-generated learning graph from syllabus."
        )
        db.add(subject)
        await db.flush()

    # Save topics to DB
    total_hours = 0.0
    topic_items = []
    for idx, t in enumerate(extracted_topics):
        t_name = t.get("name", f"Topic {idx+1}")
        t_desc = t.get("description", "")
        t_diff = float(t.get("difficulty", 0.5))
        t_prio = float(t.get("priority", 0.7))
        t_hours = float(t.get("estimated_hours", 2.0))
        total_hours += t_hours

        # Check existing
        top_res = await db.execute(
            select(Topic).where(Topic.subject_id == subject.id, Topic.name == t_name)
        )
        existing_top = top_res.scalars().first()
        if not existing_top:
            new_top = Topic(
                subject_id=subject.id,
                name=t_name,
                description=t_desc,
                difficulty=t_diff,
                priority=t_prio,
                estimated_hours=t_hours,
                order_index=idx
            )
            db.add(new_top)
            await db.flush()

            mastery = TopicMastery(
                topic_id=new_top.id,
                user_id=current_user.id,
                mastery_score=0.2,
                difficulty=t_diff,
                priority=t_prio
            )
            db.add(mastery)

            for s_idx, sub_name in enumerate(t.get("subtopics", [])):
                sub = Subtopic(topic_id=new_top.id, name=sub_name, order_index=s_idx)
                db.add(sub)

        topic_items.append(AnalyzedTopicItem(
            name=t_name,
            description=t_desc,
            difficulty=t_diff,
            priority=t_prio,
            estimated_hours=t_hours,
            subtopics=t.get("subtopics", []),
            prerequisites=t.get("prerequisites", [])
        ))

    # Log Agent Run
    agent_run = AgentRun(
        user_id=current_user.id,
        agent_name="SyllabusAnalyzerAgent",
        trigger_event="analyze_syllabus",
        input_payload={"subject": request.subject_name},
        output_summary=f"Extracted {len(extracted_topics)} topics totaling {total_hours} study hours.",
        decisions_made={"graph_edges": graph_edges}
    )
    db.add(agent_run)
    await db.commit()

    return SyllabusAnalyzeResponse(
        subject_name=request.subject_name,
        total_topics=len(topic_items),
        total_estimated_hours=round(total_hours, 1),
        topics=topic_items,
        graph_edges=graph_edges,
        analysis_notes=f"Syllabus successfully decomposed into {len(topic_items)} prioritized topics."
    )
