from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.models.user import User
from app.models.subject import Subject, Topic, Subtopic, Exam
from app.models.mastery import TopicMastery
from app.schemas.subject import (
    SubjectCreate, SubjectResponse, TopicCreate, TopicResponse,
    ExamCreate, ExamResponse
)
from app.api.deps import get_current_user

router = APIRouter(prefix="/subjects", tags=["Subjects & Syllabus"])

@router.get("", response_model=List[SubjectResponse])
async def list_subjects(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    query = (
        select(Subject)
        .where(Subject.user_id == current_user.id)
        .options(
            selectinload(Subject.topics).selectinload(Topic.subtopics),
            selectinload(Subject.topics).selectinload(Topic.mastery),
            selectinload(Subject.exams)
        )
    )
    result = await db.execute(query)
    subjects = result.scalars().all()
    return [SubjectResponse.model_validate(s) for s in subjects]

@router.post("", response_model=SubjectResponse, status_code=status.HTTP_201_CREATED)
async def create_subject(
    subject_in: SubjectCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    new_sub = Subject(
        user_id=current_user.id,
        name=subject_in.name,
        code=subject_in.code,
        description=subject_in.description,
        color=subject_in.color or "#3B82F6"
    )
    db.add(new_sub)
    await db.commit()
    await db.refresh(new_sub)
    return SubjectResponse.model_validate(new_sub)

@router.post("/topics", response_model=TopicResponse, status_code=status.HTTP_201_CREATED)
async def create_topic(
    topic_in: TopicCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Verify subject belongs to user
    res = await db.execute(select(Subject).where(Subject.id == topic_in.subject_id, Subject.user_id == current_user.id))
    if not res.scalars().first():
        raise HTTPException(status_code=404, detail="Subject not found")

    new_topic = Topic(
        subject_id=topic_in.subject_id,
        name=topic_in.name,
        description=topic_in.description,
        difficulty=topic_in.difficulty,
        priority=topic_in.priority,
        estimated_hours=topic_in.estimated_hours,
        order_index=topic_in.order_index
    )
    db.add(new_topic)
    await db.flush()

    # Initial topic mastery record
    mastery = TopicMastery(
        topic_id=new_topic.id,
        user_id=current_user.id,
        mastery_score=0.2,
        difficulty=new_topic.difficulty,
        priority=new_topic.priority
    )
    db.add(mastery)

    for idx, sub_name in enumerate(topic_in.subtopics or []):
        sub = Subtopic(topic_id=new_topic.id, name=sub_name, order_index=idx)
        db.add(sub)

    await db.commit()
    await db.refresh(new_topic)
    return TopicResponse.model_validate(new_topic)

@router.post("/exams", response_model=ExamResponse, status_code=status.HTTP_201_CREATED)
async def create_exam(
    exam_in: ExamCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    new_exam = Exam(
        user_id=current_user.id,
        subject_id=exam_in.subject_id,
        name=exam_in.name,
        exam_date=exam_in.exam_date,
        weightage=exam_in.weightage,
        target_score=exam_in.target_score
    )
    db.add(new_exam)
    await db.commit()
    await db.refresh(new_exam)
    return ExamResponse.model_validate(new_exam)
