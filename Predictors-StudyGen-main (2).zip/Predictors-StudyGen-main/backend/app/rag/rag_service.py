import os
import logging
from typing import List, Dict, Any, Optional
from app.rag.document_parser import DocumentParser
from app.rag.ocr_vision import OCRVisionService
from app.rag.chunking import TextChunker
from app.rag.vector_store import vector_store
from app.services.llm import get_llm_provider

logger = logging.getLogger(__name__)

class RAGService:
    def __init__(self):
        self.chunker = TextChunker(chunk_size=450, chunk_overlap=80)

    async def process_and_index_document(
        self,
        file_path: str,
        document_id: str,
        user_id: str,
        filename: str,
        file_type: str = "PDF"
    ) -> List[Dict[str, Any]]:
        """
        Parses document (PDF/Image/Text), chunks it, generates embeddings,
        and indexes it into Qdrant.
        """
        # 1. Parse content
        if file_type.upper() == "PDF":
            pages = DocumentParser.parse_pdf(file_path)
        elif file_type.upper() in ["IMAGE", "PNG", "JPG", "JPEG"]:
            pages = OCRVisionService.extract_text_from_image(file_path)
        else:
            pages = DocumentParser.parse_text_file(file_path)

        if not pages:
            logger.warning(f"No text extracted from document {filename}")
            return []

        # 2. Chunk text
        chunks = self.chunker.chunk_document_pages(
            pages,
            metadata={"document_id": document_id, "user_id": user_id, "filename": filename}
        )

        # 3. Generate embeddings
        llm = get_llm_provider()
        texts = [chunk["content"] for chunk in chunks]
        embeddings = await llm.get_embeddings(texts)

        # 4. Prepare payloads
        payloads = []
        for chunk in chunks:
            payloads.append({
                "document_id": document_id,
                "user_id": user_id,
                "filename": filename,
                "page_number": chunk["page_number"],
                "chunk_index": chunk["chunk_index"],
                "content": chunk["content"]
            })

        # 5. Upsert to Qdrant
        vector_ids = vector_store.upsert_chunks(embeddings, payloads)
        for i, chunk in enumerate(chunks):
            chunk["embedding_id"] = vector_ids[i]

        return chunks

    async def retrieve_context(
        self,
        query: str,
        user_id: Optional[str] = None,
        top_k: int = 4
    ) -> List[Dict[str, Any]]:
        """
        Embeds user query and searches vector store for grounded context chunks.
        """
        llm = get_llm_provider()
        query_vectors = await llm.get_embeddings([query])
        if not query_vectors:
            return []
        
        results = vector_store.search(
            query_vector=query_vectors[0],
            top_k=top_k,
            user_id=user_id
        )
        return results

rag_service = RAGService()
