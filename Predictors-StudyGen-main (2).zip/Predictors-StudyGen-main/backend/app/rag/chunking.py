import re
from typing import List, Dict, Any

class TextChunker:
    def __init__(self, chunk_size: int = 500, chunk_overlap: int = 80):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def chunk_document_pages(self, pages: List[Dict[str, Any]], metadata: Dict[str, Any] = None) -> List[Dict[str, Any]]:
        """
        Split extracted pages into overlapping chunks with precise source tracking.
        """
        chunks = []
        global_chunk_idx = 0

        for page_data in pages:
            page_num = page_data.get("page", 1)
            text = page_data.get("text", "")
            
            # Clean text
            cleaned_text = re.sub(r'\s+', ' ', text).strip()
            if not cleaned_text:
                continue

            # Paragraph and sentence splitting
            sentences = re.split(r'(?<=[.?!])\s+', cleaned_text)
            current_chunk = []
            current_len = 0

            for sentence in sentences:
                sent_len = len(sentence)
                if current_len + sent_len > self.chunk_size and current_chunk:
                    chunk_text = " ".join(current_chunk)
                    chunks.append({
                        "chunk_index": global_chunk_idx,
                        "page_number": page_num,
                        "content": chunk_text,
                        "char_count": len(chunk_text),
                        "metadata": {
                            **(metadata or {}),
                            "page": page_num,
                            "chunk_index": global_chunk_idx
                        }
                    })
                    global_chunk_idx += 1
                    
                    # Sliding overlap: keep last sentence
                    current_chunk = [current_chunk[-1]] if len(current_chunk) > 1 else []
                    current_len = len(current_chunk[0]) if current_chunk else 0

                current_chunk.append(sentence)
                current_len += sent_len

            if current_chunk:
                chunk_text = " ".join(current_chunk)
                chunks.append({
                    "chunk_index": global_chunk_idx,
                    "page_number": page_num,
                    "content": chunk_text,
                    "char_count": len(chunk_text),
                    "metadata": {
                        **(metadata or {}),
                        "page": page_num,
                        "chunk_index": global_chunk_idx
                    }
                })
                global_chunk_idx += 1

        return chunks
