import uuid
import logging
from typing import List, Dict, Any, Optional
from app.core.config import settings

logger = logging.getLogger(__name__)

class VectorStore:
    def __init__(self, collection_name: Optional[str] = None):
        self.collection_name = collection_name or settings.QDRANT_COLLECTION
        self.client = None
        self._memory_vectors: List[Dict[str, Any]] = [] # Fallback storage
        self._init_client()

    def _init_client(self):
        try:
            from qdrant_client import QdrantClient
            from qdrant_client.http import models

            if settings.QDRANT_URL == ":memory:":
                self.client = QdrantClient(":memory:")
            elif settings.QDRANT_URL and settings.QDRANT_URL.startswith("http"):
                self.client = QdrantClient(
                    url=settings.QDRANT_URL,
                    api_key=settings.QDRANT_API_KEY
                )
            else:
                self.client = QdrantClient(":memory:")

            # Ensure collection exists
            vector_size = 128 if settings.DEFAULT_LLM_PROVIDER == "mock" else 1536
            collections = self.client.get_collections().collections
            col_names = [c.name for c in collections]
            if self.collection_name not in col_names:
                self.client.create_collection(
                    collection_name=self.collection_name,
                    vectors_config=models.VectorParams(
                        size=vector_size,
                        distance=models.Distance.COSINE
                    )
                )
            logger.info(f"Qdrant VectorStore initialized on collection: {self.collection_name}")
        except Exception as e:
            logger.warning(f"Could not connect to Qdrant, using memory fallback: {e}")
            self.client = None

    def upsert_chunks(
        self,
        vectors: List[List[float]],
        payloads: List[Dict[str, Any]],
        ids: Optional[List[str]] = None
    ) -> List[str]:
        """Store chunk vectors and payloads."""
        generated_ids = ids or [str(uuid.uuid4()) for _ in vectors]

        # Dual store in memory vectors to ensure zero failure
        for pid, vec, payload in zip(generated_ids, vectors, payloads):
            self._memory_vectors.append({
                "id": pid,
                "vector": vec,
                "payload": payload
            })

        if self.client:
            try:
                from qdrant_client.http import models
                points = [
                    models.PointStruct(
                        id=pid,
                        vector=vec,
                        payload=payload
                    )
                    for pid, vec, payload in zip(generated_ids, vectors, payloads)
                ]
                self.client.upsert(
                    collection_name=self.collection_name,
                    points=points
                )
            except Exception as e:
                logger.error(f"Qdrant upsert error: {e}. Storing in local memory.")

        return generated_ids

    def search(
        self,
        query_vector: List[float],
        top_k: int = 4,
        user_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Search nearest chunks by cosine similarity."""
        # 1. Try Qdrant client if available
        if self.client:
            try:
                hits = []
                if hasattr(self.client, "query_points"):
                    res = self.client.query_points(
                        collection_name=self.collection_name,
                        query=query_vector,
                        limit=top_k
                    )
                    hits = res.points
                elif hasattr(self.client, "search"):
                    hits = self.client.search(
                        collection_name=self.collection_name,
                        query_vector=query_vector,
                        limit=top_k
                    )
                
                results = []
                for hit in hits:
                    payload = hit.payload or {}
                    if user_id and payload.get("user_id") and payload.get("user_id") != user_id:
                        continue
                    results.append({
                        "id": str(hit.id),
                        "score": getattr(hit, "score", 0.9),
                        "content": payload.get("content", ""),
                        "page_number": payload.get("page_number", 1),
                        "document_id": payload.get("document_id", ""),
                        "filename": payload.get("filename", "Uploaded Notes"),
                        "metadata": payload
                    })
                if results:
                    return results
            except Exception as e:
                logger.info(f"Qdrant client query note: {e}. Falling back to cosine memory search.")

        # In-memory cosine similarity fallback
        def cosine_sim(a: List[float], b: List[float]) -> float:
            dot = sum(x * y for x, y in zip(a, b))
            norm_a = sum(x * x for x in a) ** 0.5 or 1.0
            norm_b = sum(y * y for y in b) ** 0.5 or 1.0
            return dot / (norm_a * norm_b)

        scored = []
        for item in self._memory_vectors:
            payload = item["payload"]
            if user_id and payload.get("user_id") and payload.get("user_id") != user_id:
                continue
            sim = cosine_sim(query_vector, item["vector"])
            scored.append({
                "id": item["id"],
                "score": sim,
                "content": payload.get("content", ""),
                "page_number": payload.get("page_number", 1),
                "document_id": payload.get("document_id", ""),
                "filename": payload.get("filename", "Uploaded Notes"),
                "metadata": payload
            })

        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]

# Global singleton
vector_store = VectorStore()
