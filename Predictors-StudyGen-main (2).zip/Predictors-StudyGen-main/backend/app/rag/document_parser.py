import os
import pymupdf as fitz
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class DocumentParser:
    @staticmethod
    def parse_pdf(file_path: str) -> List[Dict[str, Any]]:
        """
        Extract text page-by-page from a PDF using PyMuPDF.
        Returns a list of dicts: [{"page": 1, "text": "...", "char_count": 120}]
        """
        pages_content = []
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"PDF file not found: {file_path}")

        try:
            doc = fitz.open(file_path)
            for page_index in range(len(doc)):
                page = doc[page_index]
                text = page.get_text("text").strip()
                if text:
                    pages_content.append({
                        "page": page_index + 1,
                        "text": text,
                        "char_count": len(text)
                    })
            doc.close()
        except Exception as e:
            logger.error(f"Error parsing PDF {file_path}: {e}")
            raise e

        return pages_content

    @staticmethod
    def parse_text_file(file_path: str) -> List[Dict[str, Any]]:
        """Parse raw text/markdown file."""
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read().strip()
        return [{
            "page": 1,
            "text": content,
            "char_count": len(content)
        }]
