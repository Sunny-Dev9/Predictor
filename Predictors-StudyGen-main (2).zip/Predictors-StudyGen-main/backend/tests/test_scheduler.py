from datetime import date
from app.scheduler.engine import SmartScheduler

def test_smart_scheduler_generates_tasks():
    topics = [
        {"id": "t1", "name": "Binary Trees", "difficulty": 0.8, "priority": 0.9, "mastery_score": 0.45, "subject_id": "s1"},
        {"id": "t2", "name": "Arrays", "difficulty": 0.3, "priority": 0.7, "mastery_score": 0.85, "subject_id": "s1"},
    ]
    exams = [
        {"name": "DSA Final", "exam_date": date(2026, 9, 25), "subject_id": "s1"}
    ]

    schedule = SmartScheduler.generate_schedule(
        topics_data=topics,
        exams_data=exams,
        start_date=date(2026, 9, 6),
        days_ahead=7,
        available_hours_per_day=2.0,
        preferred_time="Evening"
    )

    assert len(schedule) > 0
    # Every task should have an explainable reason
    for task in schedule:
        assert task["reason"] is not None
        assert len(task["reason"]) > 10
        assert task["start_time"] is not None
        assert task["scheduled_date"] is not None
        assert task["duration_minutes"] == 60

def test_smart_scheduler_prioritizes_weak_topics():
    topics = [
        {"id": "t1", "name": "Weak Topic", "difficulty": 0.9, "priority": 0.9, "mastery_score": 0.20, "subject_id": "s1"},
        {"id": "t2", "name": "Strong Topic", "difficulty": 0.3, "priority": 0.5, "mastery_score": 0.90, "subject_id": "s1"},
    ]
    schedule = SmartScheduler.generate_schedule(
        topics_data=topics,
        exams_data=[],
        days_ahead=3,
        available_hours_per_day=1.0
    )

    assert len(schedule) == 3
    # The first task scheduled should be the weak topic
    assert schedule[0]["topic_id"] == "t1"
    assert "Low mastery" in schedule[0]["reason"]
