import pytest
from app.rag.chunking import TextChunker
from app.rag.vector_store import VectorStore

def test_chunker_splits_and_tracks_pages():
    chunker = TextChunker(chunk_size=100, chunk_overlap=20)
    pages = [
        {"page": 1, "text": "This is a comprehensive overview of tree balancing. Rotations maintain the invariant."},
        {"page": 2, "text": "In AVL trees, the balance factor is calculated as height of left minus right subtree."}
    ]
    chunks = chunker.chunk_document_pages(pages, metadata={"doc_id": "doc123"})
    assert len(chunks) >= 2
    assert chunks[0]["page_number"] == 1
    assert chunks[-1]["page_number"] == 2
    assert "metadata" in chunks[0]

def test_vector_store_in_memory_search():
    store = VectorStore(collection_name="test_collection")
    vectors = [
        [1.0] + [0.0] * 127,
        [0.0, 1.0] + [0.0] * 126
    ]
    payloads = [
        {"content": "AVL trees are balanced binary search trees", "page_number": 1},
        {"content": "Relational databases use SQL for querying", "page_number": 2}
    ]
    store.upsert_chunks(vectors, payloads)

    # Search with query vector closest to first item
    query_vec = [0.9] + [0.1] * 127
    results = store.search(query_vec, top_k=1)
    assert len(results) == 1
    assert "AVL" in results[0]["content"]
