import asyncio
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.core.database import init_db

client = TestClient(app)

@pytest.fixture(scope="session", autouse=True)
def setup_test_db():
    asyncio.run(init_db())

def test_health_check():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"

def test_demo_seed_endpoint():
    response = client.post("/api/v1/demo/seed")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "success"
    assert "access_token" in data
    assert data["scenario"]["weak_topic"] is not None

def test_ml_predict_endpoint():
    payload = {
        "quiz_score_avg": 75.0,
        "study_duration_hrs": 4.0,
        "session_count": 4,
        "topic_difficulty": 0.6,
        "completion_rate": 0.8,
        "recent_quiz_score": 78.0,
        "revision_frequency": 2
    }
    response = client.post("/api/v1/ml/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert 0.0 <= data["mastery_probability"] <= 1.0
    assert "recommended_action" in data
