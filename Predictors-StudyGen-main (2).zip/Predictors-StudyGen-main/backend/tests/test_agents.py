import pytest
from app.agents.graph import learner_graph_app

@pytest.mark.asyncio
async def test_syllabus_and_planner_agent_flow():
    initial_state = {
        "user_id": "test_user_1",
        "action_trigger": "analyze_syllabus",
        "subject_name": "Data Structures",
        "raw_syllabus": "Unit 1: Arrays, Unit 2: Binary Trees, Unit 3: Graphs",
        "topics": [],
        "exams": [],
        "learning_graph_edges": [],
        "available_hours_per_day": 2.0,
        "preferred_study_time": "Evening",
        "days_ahead": 5,
        "study_tasks": [],
        "current_plan_explanation": None,
        "active_topic_id": None,
        "generated_quiz": None,
        "quiz_submission": None,
        "quiz_score": None,
        "mastery_updates": {},
        "replan_needed": False,
        "replan_reason": None,
        "remedial_topics": [],
        "advanced_topics": [],
        "query_text": None,
        "retrieved_chunks": [],
        "tutor_answer": None,
        "citations": [],
        "learner_memory": {},
        "agent_logs": [],
        "error": None
    }

    result = await learner_graph_app.ainvoke(initial_state)
    assert len(result["topics"]) > 0
    assert len(result["study_tasks"]) > 0
    assert result["current_plan_explanation"] is not None

@pytest.mark.asyncio
async def test_quiz_and_performance_agent_flow():
    state = {
        "user_id": "test_user_2",
        "action_trigger": "evaluate_performance",
        "raw_syllabus": None,
        "subject_name": None,
        "topics": [{"id": "t_tree", "name": "Binary Trees"}],
        "exams": [],
        "learning_graph_edges": [],
        "available_hours_per_day": 3.0,
        "preferred_study_time": "Evening",
        "days_ahead": 7,
        "study_tasks": [],
        "current_plan_explanation": None,
        "active_topic_id": "t_tree",
        "generated_quiz": None,
        "quiz_submission": {},
        "quiz_score": 45.0, # Low score triggers replanning
        "mastery_updates": {},
        "replan_needed": False,
        "replan_reason": None,
        "remedial_topics": [],
        "advanced_topics": [],
        "query_text": None,
        "retrieved_chunks": [],
        "tutor_answer": None,
        "citations": [],
        "learner_memory": {},
        "agent_logs": [],
        "error": None
    }

    result = await learner_graph_app.ainvoke(state)
    # Since score was 45.0, conditional edge routes to replanning
    assert "t_tree" in result.get("remedial_topics", [])
    assert "Binary Trees" in result.get("learner_memory", {}).get("weak_topics", [])
