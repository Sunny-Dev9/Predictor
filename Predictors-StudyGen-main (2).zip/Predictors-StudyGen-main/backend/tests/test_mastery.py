from app.services.mastery import MasteryEngine

def test_mastery_calculation_formula():
    # mastery = 0.4 * quiz + 0.2 * comp + 0.2 * const + 0.2 * recent
    score = MasteryEngine.calculate_composite_mastery(
        quiz_performance=0.5,
        completion_rate=1.0,
        consistency_score=1.0,
        recent_performance=0.5
    )
    # Expected: 0.4*0.5 + 0.2*1.0 + 0.2*1.0 + 0.2*0.5 = 0.2 + 0.2 + 0.2 + 0.1 = 0.7
    assert abs(score - 0.7) < 0.01

def test_quiz_adaptation_rules():
    # Low score < 50% triggers remedial learning
    low_result = MasteryEngine.evaluate_quiz_and_adapt(
        quiz_score_pct=45.0,
        previous_mastery=0.6,
        study_count=2
    )
    assert low_result["action"] == "SCHEDULE_REMEDIAL"
    assert low_result["replan_required"] is True
    assert low_result["is_remedial"] is True

    # High score > 80% advances topic
    high_result = MasteryEngine.evaluate_quiz_and_adapt(
        quiz_score_pct=90.0,
        previous_mastery=0.7,
        study_count=4
    )
    assert high_result["action"] == "ADVANCE_TOPIC"
    assert high_result["replan_required"] is False
