import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatMinutes(minutes: number): string {
  const hrs = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hrs > 0 && mins > 0) return `${hrs}h ${mins}m`;
  if (hrs > 0) return `${hrs}h`;
  return `${mins}m`;
}

export function getMasteryColor(score: number): { text: string; bg: string; border: string; label: string } {
  if (score < 0.50) {
    return { text: "text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/30", label: "Weak" };
  }
  if (score < 0.75) {
    return { text: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/30", label: "Moderate" };
  }
  return { text: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/30", label: "Mastered" };
}
