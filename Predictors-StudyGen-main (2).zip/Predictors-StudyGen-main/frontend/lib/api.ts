const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

function getToken(): string | null {
  if (typeof window !== "undefined") {
    return localStorage.getItem("studygen_token");
  }
  return null;
}

export function setToken(token: string) {
  if (typeof window !== "undefined") {
    localStorage.setItem("studygen_token", token);
  }
}

export function clearToken() {
  if (typeof window !== "undefined") {
    localStorage.removeItem("studygen_token");
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string>),
  };

  if (!(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
  }

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const url = `${API_BASE}${endpoint}`;
  try {
    const res = await fetch(url, { ...options, headers });
    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.detail || `Request failed with status ${res.status}`);
    }
    return (await res.json()) as T;
  } catch (err: any) {
    console.warn(`API request to ${endpoint} failed:`, err.message);
    throw err;
  }
}

export const api = {
  // Demo Seeder
  seedDemo: async () => {
    const data = await request<any>("/demo/seed", { method: "POST" });
    if (data.access_token) {
      setToken(data.access_token);
    }
    return data;
  },

  // Auth
  login: async (email: string, password: string) => {
    const data = await request<any>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
    if (data.access_token) setToken(data.access_token);
    return data;
  },
  register: async (email: string, password: string, fullName: string) => {
    const data = await request<any>("/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password, full_name: fullName }),
    });
    if (data.access_token) setToken(data.access_token);
    return data;
  },
  getMe: () => request<any>("/auth/me"),

  // Profile
  getProfile: () => request<any>("/profile"),
  updateProfile: (profile: any) =>
    request<any>("/profile", {
      method: "PUT",
      body: JSON.stringify(profile),
    }),

  // Subjects & Syllabus
  listSubjects: () => request<any[]>("/subjects"),
  createSubject: (sub: { name: string; code?: string; color?: string; description?: string }) =>
    request<any>("/subjects", {
      method: "POST",
      body: JSON.stringify(sub),
    }),
  analyzeSyllabus: (subjectName: string, rawText: string) =>
    request<any>("/syllabus/analyze", {
      method: "POST",
      body: JSON.stringify({ subject_name: subjectName, raw_syllabus_text: rawText }),
    }),

  // Plans & Tasks
  generatePlan: (daysAhead = 14) =>
    request<any>("/plans/generate", {
      method: "POST",
      body: JSON.stringify({ days_ahead: daysAhead }),
    }),
  getCurrentPlan: () => request<any[]>("/plans/current"),
  replan: (reason: string, topicId?: string) =>
    request<any>("/plans/replan", {
      method: "POST",
      body: JSON.stringify({ reason, triggered_topic_id: topicId }),
    }),
  completeTask: (taskId: string, durationMinutes = 45, notes = "") =>
    request<any>(`/tasks/${taskId}/complete`, {
      method: "POST",
      body: JSON.stringify({ task_id: taskId, duration_minutes: durationMinutes, notes }),
    }),
  skipTask: (taskId: string) =>
    request<any>(`/tasks/${taskId}/skip`, { method: "POST" }),

  // Quiz
  generateQuiz: (topicId: string, numQuestions = 4) =>
    request<any>("/quiz/generate", {
      method: "POST",
      body: JSON.stringify({ topic_id: topicId, num_questions: numQuestions }),
    }),
  submitQuiz: (attemptId: string, answers: { question_id: string; student_answer: string }[]) =>
    request<any>("/quiz/submit", {
      method: "POST",
      body: JSON.stringify({ attempt_id: attemptId, answers, time_taken_seconds: 110 }),
    }),

  // Progress & Analytics
  getProgress: () => request<any>("/progress"),
  getAnalytics: () => request<any>("/progress/analytics"),

  // Documents / RAG
  listDocuments: () => request<any[]>("/documents"),
  uploadDocument: async (file: File) => {
    const formData = new FormData();
    formData.append("file", file);
    return request<any>("/documents/upload", {
      method: "POST",
      body: formData,
    });
  },

  // Tutor Chat
  chatTutor: (message: string, topicId?: string) =>
    request<any>("/chat", {
      method: "POST",
      body: JSON.stringify({ message, topic_id: topicId }),
    }),

  // ML Mastery Predictor
  predictMastery: (params: any) =>
    request<any>("/ml/predict", {
      method: "POST",
      body: JSON.stringify(params),
    }),
};
