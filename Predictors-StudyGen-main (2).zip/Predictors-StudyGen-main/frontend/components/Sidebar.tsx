"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  CalendarDays,
  BookOpen,
  Timer,
  CheckSquare,
  Bot,
  FileText,
  LineChart,
  Settings,
  Sparkles,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV_ITEMS = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/planner", label: "Smart Planner", icon: CalendarDays },
  { href: "/subjects", label: "Syllabus Graph", icon: BookOpen },
  { href: "/study", label: "Study Session", icon: Timer },
  { href: "/quiz", label: "Adaptive Quizzes", icon: CheckSquare },
  { href: "/tutor", label: "AI Tutor (RAG)", icon: Bot },
  { href: "/materials", label: "Study Materials", icon: FileText },
  { href: "/progress", label: "ML & Analytics", icon: LineChart },
  { href: "/settings", label: "Settings", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 border-r border-border/50 bg-slate-950/80 backdrop-blur-xl flex flex-col h-screen fixed left-0 top-0 z-40">
      {/* Brand Header */}
      <div className="p-5 border-b border-border/40 flex items-center gap-3">
        <div className="h-9 w-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
          <Sparkles className="h-5 w-5 text-white" />
        </div>
        <div>
          <h1 className="font-bold text-lg leading-none gradient-text">StudyGen</h1>
          <p className="text-xs text-muted-foreground mt-1">Agentic AI Planner</p>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {NAV_ITEMS.map((item) => {
          const isActive = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150",
                isActive
                  ? "bg-blue-600/15 text-blue-400 border border-blue-500/30 shadow-sm"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/60"
              )}
            >
              <Icon className={cn("h-4 w-4", isActive ? "text-blue-400" : "text-slate-400")} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* Agent Status Indicator */}
      <div className="p-4 border-t border-border/40 m-3 rounded-xl bg-slate-900/50 border">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="text-slate-400 font-medium flex items-center gap-1.5">
            <Zap className="h-3.5 w-3.5 text-amber-400" /> LangGraph Active
          </span>
          <span className="text-emerald-400 font-semibold text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20">
            Online
          </span>
        </div>
        <p className="text-[11px] text-slate-500">
          7 specialized agents continuously observing & replanning.
        </p>
      </div>
    </aside>
  );
}
