"use client";

import { useState } from "react";
import { X, ChevronRight, ChevronLeft, CheckCircle2, Bot, Calendar, Sparkles, Brain } from "lucide-react";

interface DemoWalkthroughModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (path: string) => void;
}

const STEPS = [
  {
    step: 1,
    title: "Exam Goals & Constraints",
    agent: "Planning Agent",
    description: "Student enters target exam in 20 days (Data Structures Final), 3 available study hours/day, and Evening preferred slot.",
    actionLink: "/planner",
    actionLabel: "View 20-Day Plan",
    highlight: "3 hrs/day | 20 Days Remaining | 4 Subjects"
  },
  {
    step: 2,
    title: "Syllabus Deconstruction & Learning Graph",
    agent: "Syllabus Analyzer Agent",
    description: "The Syllabus Analyzer parses raw curriculum text, estimates difficulty (0.1 - 1.0), and links prerequisites into a directed learning graph.",
    actionLink: "/subjects",
    actionLabel: "Inspect Topic Graph",
    highlight: "6 Topics | 18 Subtopics | Prerequisite Edges"
  },
  {
    step: 3,
    title: "Smart Constraint Scheduling",
    agent: "Planning Agent (SmartScheduler)",
    description: "Distributes topics across days, embedding 10-minute breaks between 50-minute study blocks. Every task contains a transparent reason: 'Why was this scheduled?'",
    actionLink: "/planner",
    actionLabel: "Open Smart Calendar",
    highlight: "Explainable Decisions on Every Time Slot"
  },
  {
    step: 4,
    title: "Multimodal Notes & RAG Ingestion",
    agent: "Tutor RAG Agent",
    description: "Student uploads 'DSA_Lecture_Notes_Trees_AVL.pdf'. PyMuPDF extracts pages, TextChunker creates overlapping segments, and vectors are indexed in Qdrant.",
    actionLink: "/materials",
    actionLabel: "View Uploaded PDF",
    highlight: "PyMuPDF + Recursive Chunking + Qdrant"
  },
  {
    step: 5,
    title: "Diagnostic Quiz Generation",
    agent: "Quiz Agent",
    description: "Quiz Agent generates 4 conceptual questions on Binary Trees and AVL invariants. The student attempts the test and scores 45%.",
    actionLink: "/quiz",
    actionLabel: "Take Diagnostic Quiz",
    highlight: "Student Score: 45% (Below Mastery Threshold)"
  },
  {
    step: 6,
    title: "Adaptive Mastery & Replanning Trigger",
    agent: "Performance Agent & Replanning Agent",
    description: "Performance Agent flags low mastery (45% < 50%). LangGraph routes dynamically to ReplanningAgent: 2 prioritized revision sessions are injected into upcoming days!",
    actionLink: "/planner",
    actionLabel: "Verify Replanned Tasks",
    highlight: "Auto-Replan: Injected 2 Binary Trees Revision Sessions"
  },
  {
    step: 7,
    title: "Grounded AI Tutor with Citations",
    agent: "Tutor RAG Agent",
    description: "Student asks 'Explain AVL trees using my notes'. The Tutor Agent retrieves nearest chunks and quotes page numbers directly without hallucinations.",
    actionLink: "/tutor",
    actionLabel: "Chat with AI Tutor",
    highlight: "Answers with Source Page & Similarity Citations"
  },
  {
    step: 8,
    title: "ML Topic Mastery Predictor",
    agent: "Adaptive ML Engine (RandomForest / MLflow)",
    description: "Trained Scikit-Learn model calculates the exact probability of student mastering a topic before the exam based on quiz history and consistency.",
    actionLink: "/progress",
    actionLabel: "Simulate ML Predictions",
    highlight: "Accuracy 66% | F1 0.57 | MLflow Tracked"
  }
];

export function DemoWalkthroughModal({ isOpen, onClose, onNavigate }: DemoWalkthroughModalProps) {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  if (!isOpen) return null;

  const current = STEPS[currentStepIndex];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center">
              <Brain className="h-4 w-4 text-blue-400" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-100 text-sm">StudyGen Hackathon Pitch Walkthrough</h3>
              <p className="text-xs text-slate-400">Step-by-step verification of Agentic AI & RAG loop</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="px-2.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400">
              Step {current.step} of {STEPS.length}: {current.agent}
            </span>
            <span className="text-slate-400">
              PLAN → LEARN → MEASURE → REMEMBER → ADAPT → REPLAN
            </span>
          </div>

          <h2 className="text-xl font-bold text-white">{current.title}</h2>
          <p className="text-sm text-slate-300 leading-relaxed">{current.description}</p>

          <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center gap-3">
            <Sparkles className="h-4 w-4 text-amber-400 shrink-0" />
            <div className="text-xs font-mono text-amber-300">
              Key Outcome: {current.highlight}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-5 border-t border-slate-800 bg-slate-950/50 flex items-center justify-between">
          <button
            onClick={() => setCurrentStepIndex((prev) => Math.max(0, prev - 1))}
            disabled={currentStepIndex === 0}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white disabled:opacity-30"
          >
            <ChevronLeft className="h-3.5 w-3.5" /> Previous
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onNavigate(current.actionLink);
                onClose();
              }}
              className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 transition"
            >
              {current.actionLabel}
            </button>

            {currentStepIndex < STEPS.length - 1 ? (
              <button
                onClick={() => setCurrentStepIndex((prev) => Math.min(STEPS.length - 1, prev + 1))}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition"
              >
                Next Step <ChevronRight className="h-3.5 w-3.5" />
              </button>
            ) : (
              <button
                onClick={onClose}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-medium transition"
              >
                Done <CheckCircle2 className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
