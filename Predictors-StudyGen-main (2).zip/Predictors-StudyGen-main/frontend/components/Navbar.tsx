"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Sparkles, Play, Flame, BookOpen } from "lucide-react";
import { api } from "@/lib/api";

interface NavbarProps {
  title: string;
  subtitle?: string;
  onDemoSeeded?: () => void;
  onOpenWalkthrough?: () => void;
}

export function Navbar({ title, subtitle, onDemoSeeded, onOpenWalkthrough }: NavbarProps) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSeedDemo = async () => {
    setLoading(true);
    try {
      await api.seedDemo();
      if (onDemoSeeded) {
        onDemoSeeded();
      } else {
        router.refresh();
      }
    } catch (err) {
      console.error("Demo seeding error:", err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <header className="h-16 border-b border-border/50 bg-slate-950/60 backdrop-blur-xl px-6 flex items-center justify-between sticky top-0 z-30 ml-64">
      <div>
        <h2 className="text-lg font-semibold text-slate-100">{title}</h2>
        {subtitle && <p className="text-xs text-slate-400">{subtitle}</p>}
      </div>

      <div className="flex items-center gap-3">
        {/* Streak Counter */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold">
          <Flame className="h-4 w-4 text-amber-400 animate-pulse" />
          <span>5 Day Streak</span>
        </div>

        {/* Walkthrough Modal Trigger */}
        {onOpenWalkthrough && (
          <button
            onClick={onOpenWalkthrough}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 text-slate-200 text-xs font-medium transition"
          >
            <BookOpen className="h-3.5 w-3.5 text-blue-400" />
            <span>Judge Demo Pitch</span>
          </button>
        )}

        {/* 1-Click Hackathon Demo Button */}
        <button
          onClick={handleSeedDemo}
          disabled={loading}
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-medium shadow-md shadow-blue-500/20 border border-blue-400/30 transition disabled:opacity-60"
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span>{loading ? "Seeding..." : "Load Demo Scenario"}</span>
        </button>
      </div>
    </header>
  );
}
