import type { Metadata } from "next";
import "./globals.css";
import { Sidebar } from "@/components/Sidebar";

export const metadata: Metadata = {
  title: "StudyGen — Agentic AI Study Planner",
  description: "Adaptive AI learning assistant powered by LangGraph, Multimodal RAG, and Adaptive ML.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-background text-foreground antialiased min-h-screen flex">
        <Sidebar />
        <main className="flex-1 min-h-screen ml-64 flex flex-col bg-slate-950/40">
          {children}
        </main>
      </body>
    </html>
  );
}
