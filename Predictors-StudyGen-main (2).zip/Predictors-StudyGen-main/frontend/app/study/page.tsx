"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  Timer,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  BookOpen,
  ArrowRight,
  Brain,
  Check,
} from "lucide-react";
import { api } from "@/lib/api";

function StudySessionContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const taskId = searchParams.get("taskId") || "demo-task";

  const [secondsLeft, setSecondsLeft] = useState(50 * 60); // 50-minute study block
  const [isActive, setIsActive] = useState(false);
  const [notes, setNotes] = useState("");
  const [completed, setCompleted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (isActive && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((sec) => sec - 1);
      }, 1000);
    } else if (secondsLeft === 0) {
      setIsActive(false);
    }
    return () => clearInterval(interval);
  }, [isActive, secondsLeft]);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setSecondsLeft(50 * 60);
  };

  const formatTime = (totalSec: number) => {
    const mins = Math.floor(totalSec / 60);
    const secs = totalSec % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleFinishSession = async () => {
    setSubmitting(true);
    try {
      await api.completeTask(taskId, 50, notes);
      setCompleted(true);
    } catch (e) {
      console.error(e);
      setCompleted(true);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="p-8 space-y-8 max-w-4xl mx-auto w-full">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-white tracking-tight">Active Focus Session</h1>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 border border-blue-500/20 text-blue-400">
            50-Min Block + 10-Min Break
          </span>
        </div>
        <p className="text-sm text-slate-400 mt-1">
          Deep work block optimized for maximum memory consolidation and minimal cognitive fatigue.
        </p>
      </div>

      {/* Timer Card */}
      <div className="p-8 rounded-3xl glass-panel border text-center space-y-6">
        <span className="text-xs font-semibold uppercase tracking-widest text-slate-400">
          Target Focus: Binary Trees & AVL Balancing
        </span>

        <div className="text-7xl font-mono font-bold text-white tracking-tight">
          {formatTime(secondsLeft)}
        </div>

        {/* Timer Controls */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={toggleTimer}
            className={`px-6 py-3 rounded-2xl text-sm font-semibold flex items-center gap-2 transition shadow-lg ${
              isActive
                ? "bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30"
                : "bg-blue-600 hover:bg-blue-500 text-white shadow-blue-500/25"
            }`}
          >
            {isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            <span>{isActive ? "Pause Focus" : "Start Focus Timer"}</span>
          </button>

          <button
            onClick={resetTimer}
            className="p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Session Notes & Completion */}
      <div className="p-6 rounded-2xl glass-panel border space-y-4">
        <h3 className="font-semibold text-white text-base flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-blue-400" /> Session Notes & Active Recall
        </h3>
        <textarea
          rows={4}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Record key formulas, balance factor rules, code snippets, or unresolved questions..."
          className="w-full p-4 rounded-xl bg-slate-900 border border-slate-800 text-sm text-white focus:outline-none focus:border-blue-500 leading-relaxed"
        />

        {!completed ? (
          <button
            onClick={handleFinishSession}
            disabled={submitting}
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
          >
            <Check className="h-4 w-4" />
            <span>{submitting ? "Saving Progress..." : "Mark Session as Completed"}</span>
          </button>
        ) : (
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-2">
            <div className="text-emerald-300 font-semibold text-sm flex items-center justify-center gap-1.5">
              <CheckCircle2 className="h-4 w-4" /> Session recorded! Streak and mastery updated.
            </div>
            <button
              onClick={() => router.push("/quiz")}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition inline-flex items-center gap-1.5"
            >
              Take Immediate Quiz to Verify Mastery <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function StudySessionPage() {
  return (
    <Suspense fallback={<div className="p-8 text-slate-400">Loading focus session...</div>}>
      <StudySessionContent />
    </Suspense>
  );
}
