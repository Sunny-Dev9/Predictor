"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Sparkles, Calendar, Clock, BookOpen, ArrowRight } from "lucide-react";
import { api } from "@/lib/api";

export default function OnboardingPage() {
  const router = useRouter();
  const [examDays, setExamDays] = useState(20);
  const [dailyHours, setDailyHours] = useState(3.0);
  const [preferredTime, setPreferredTime] = useState("Evening");
  const [subjects, setSubjects] = useState("Data Structures & Algorithms, DBMS, Operating Systems, Machine Learning");
  const [loading, setLoading] = useState(false);

  const handleFinish = async () => {
    setLoading(true);
    try {
      await api.updateProfile({
        available_hours_per_day: dailyHours,
        preferred_study_time: preferredTime,
        onboarding_completed: true,
      });
      router.push("/dashboard");
    } catch (e) {
      router.push("/dashboard");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-xl p-8 rounded-3xl glass-panel border shadow-2xl space-y-6">
        <div className="space-y-2 text-center">
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20">
            Initial Learner Setup
          </span>
          <h1 className="text-2xl font-bold text-white tracking-tight">Configure Your Study Goals</h1>
          <p className="text-xs text-slate-400">
            The Agentic AI scheduler calibrates its multi-agent intelligence to your exact calendar constraints.
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-300">Days Until Main Finals</label>
            <div className="mt-1.5 flex items-center gap-3">
              <input
                type="number"
                min="1"
                max="120"
                value={examDays}
                onChange={(e) => setExamDays(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500"
              />
              <span className="text-xs text-slate-400 shrink-0">Days Remaining</span>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300">Daily Available Study Hours</label>
            <div className="mt-1.5 flex items-center gap-3">
              <input
                type="number"
                step="0.5"
                min="1"
                max="10"
                value={dailyHours}
                onChange={(e) => setDailyHours(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500"
              />
              <span className="text-xs text-slate-400 shrink-0">Hours / Day</span>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300">Preferred Study Window</label>
            <select
              value={preferredTime}
              onChange={(e) => setPreferredTime(e.target.value)}
              className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500"
            >
              <option value="Morning">Morning (08:00 - 11:30)</option>
              <option value="Afternoon">Afternoon (14:00 - 17:30)</option>
              <option value="Evening">Evening (18:00 - 21:30)</option>
              <option value="Night">Night (21:00 - 00:30)</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300">Subjects to Prepare</label>
            <input
              type="text"
              value={subjects}
              onChange={(e) => setSubjects(e.target.value)}
              className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500"
              placeholder="e.g. DSA, DBMS, OS"
            />
          </div>
        </div>

        <button
          onClick={handleFinish}
          disabled={loading}
          className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-sm transition shadow-xl shadow-blue-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
        >
          <span>{loading ? "Calibrating Agents..." : "Generate AI Study Plan"}</span>
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
