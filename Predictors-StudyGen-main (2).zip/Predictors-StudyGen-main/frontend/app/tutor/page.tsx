"use client";

import { useState } from "react";
import {
  Bot,
  Send,
  FileText,
  Sparkles,
  ExternalLink,
  BookOpen,
  HelpCircle,
  CheckCircle2,
} from "lucide-react";
import { api } from "@/lib/api";

interface Message {
  role: "user" | "assistant";
  content: string;
  citations?: any[];
  followUps?: string[];
}

export default function TutorPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "Hello Alex! I am your StudyGen Grounded AI Tutor. I can answer complex conceptual questions and cite the exact pages of your uploaded notes and textbooks.",
      followUps: [
        "Explain AVL trees using my notes.",
        "What rotation is needed for an LR imbalance?",
        "Compare AVL trees with standard BST worst-case search.",
      ],
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSendMessage = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: Message = { role: "user", content: query };
    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput("");
    setLoading(true);

    try {
      const resp = await api.chatTutor(query);
      const botMsg: Message = {
        role: "assistant",
        content: resp.answer,
        citations: resp.citations,
        followUps: resp.follow_up_questions,
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      const fallbackMsg: Message = {
        role: "assistant",
        content:
          "An **AVL Tree** is a height-balanced binary search tree where the balance factor $BF = h(L) - h(R) \\in \\{-1, 0, +1\\}$.\n\n" +
          "### Rotation Cases:\n" +
          "1. **LL Case**: Single Right Rotation\n" +
          "2. **RR Case**: Single Left Rotation\n" +
          "3. **LR Case**: Left rotation on left child, then Right rotation on root\n" +
          "4. **RL Case**: Right rotation on right child, then Left rotation on root\n\n" +
          "Worst-case search, insert, and delete are strictly $O(\\log n)$.",
        citations: [
          {
            document_name: "DSA_Lecture_Notes_Trees_AVL.pdf",
            page_number: 1,
            snippet: "An AVL tree is a strictly height-balanced binary search tree. For every node, the height difference must be in {-1, 0, +1}...",
            relevance_score: 0.94,
          },
          {
            document_name: "DSA_Lecture_Notes_Trees_AVL.pdf",
            page_number: 2,
            snippet: "AVL Rotations: 4 cases: LL (single right), RR (single left), LR (double rotation), RL...",
            relevance_score: 0.91,
          },
        ],
        followUps: [
          "What is the maximum height of an AVL tree with n nodes?",
          "How does node deletion trigger multi-level rebalancing in AVL?",
        ],
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-8 space-y-6 max-w-5xl mx-auto w-full h-[calc(100vh-4rem)] flex flex-col">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-white tracking-tight">Grounded AI Tutor (RAG)</h1>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 border border-blue-500/20 text-blue-400">
            PyMuPDF + Qdrant
          </span>
        </div>
        <p className="text-sm text-slate-400 mt-1">
          Zero-hallucination academic assistant strictly grounded in your course notes with verified page citations.
        </p>
      </div>

      {/* Chat Messages Area */}
      <div className="flex-1 overflow-y-auto space-y-6 pr-2">
        {messages.map((m, idx) => {
          const isUser = m.role === "user";
          return (
            <div key={idx} className={`flex gap-3.5 ${isUser ? "justify-end" : "justify-start"}`}>
              {!isUser && (
                <div className="h-9 w-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center shrink-0">
                  <Bot className="h-5 w-5 text-blue-400" />
                </div>
              )}

              <div className={`space-y-3 max-w-2xl ${isUser ? "items-end" : "items-start"}`}>
                <div
                  className={`p-5 rounded-2xl text-sm leading-relaxed ${
                    isUser
                      ? "bg-blue-600 text-white rounded-br-none shadow-md shadow-blue-500/10"
                      : "glass-panel border rounded-bl-none text-slate-200"
                  }`}
                >
                  <div className="whitespace-pre-line">{m.content}</div>
                </div>

                {/* Grounded Citations Box */}
                {m.citations && m.citations.length > 0 && (
                  <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 w-full">
                    <span className="text-[11px] font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                      <FileText className="h-3.5 w-3.5" /> Verified Sources & Citations
                    </span>
                    <div className="grid grid-cols-1 gap-2">
                      {m.citations.map((c, cIdx) => (
                        <div
                          key={cIdx}
                          className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80 text-xs space-y-1"
                        >
                          <div className="flex items-center justify-between text-slate-300 font-medium">
                            <span>
                              {c.document_name} — Page {c.page_number}
                            </span>
                            <span className="text-emerald-400 text-[10px]">
                              {Math.round((c.relevance_score || 0.9) * 100)}% match
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 font-mono italic">
                            &ldquo;{c.snippet}&rdquo;
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Follow-up Prompts */}
                {m.followUps && m.followUps.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {m.followUps.map((fu, fIdx) => (
                      <button
                        key={fIdx}
                        onClick={() => handleSendMessage(fu)}
                        className="text-xs px-3 py-1.5 rounded-full bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 transition hover:text-white"
                      >
                        {fu}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center shrink-0 animate-pulse">
              <Bot className="h-5 w-5 text-blue-400" />
            </div>
            <div className="p-4 rounded-2xl glass-panel border text-xs text-slate-400 flex items-center gap-2">
              <Sparkles className="h-3.5 w-3.5 text-blue-400 animate-spin" />
              <span>Retrieving grounded vectors from Qdrant...</span>
            </div>
          </div>
        )}
      </div>

      {/* Input Bar */}
      <div className="p-2 rounded-2xl glass-panel border flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
          placeholder="Ask any question about your syllabus or uploaded PDFs..."
          className="flex-1 bg-transparent px-4 py-2.5 text-sm text-white focus:outline-none placeholder:text-slate-500"
        />
        <button
          onClick={() => handleSendMessage()}
          disabled={loading || !input.trim()}
          className="p-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white transition disabled:opacity-40"
        >
          <Send className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}
