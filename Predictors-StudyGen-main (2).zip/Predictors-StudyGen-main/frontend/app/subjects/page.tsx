"use client";

import { useEffect, useState } from "react";
import {
  BookOpen,
  Sparkles,
  ArrowRight,
  Sliders,
  Layers,
  CheckCircle,
  Clock,
  Plus,
} from "lucide-react";
import { api } from "@/lib/api";
import { getMasteryColor } from "@/lib/utils";

export default function SubjectsPage() {
  const [subjects, setSubjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [subjectName, setSubjectName] = useState("Data Structures & Algorithms");
  const [rawSyllabus, setRawSyllabus] = useState(
    "Module 1: Linear Data Structures - Arrays, Linked Lists, Stacks, Queues.\n" +
    "Module 2: Hierarchical Structures - Trees, Binary Search Trees, AVL Trees, Balance Factors.\n" +
    "Module 3: Graph Algorithms - BFS, DFS, Shortest Path, Dijkstra, Topological Sort.\n" +
    "Module 4: Dynamic Programming - Memoization, Tabulation, Knapsack, LCS."
  );

  const loadSubjects = async () => {
    try {
      setLoading(true);
      const data = await api.listSubjects();
      setSubjects(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSubjects();
  }, []);

  const handleAnalyze = async () => {
    if (!rawSyllabus.trim()) return;
    setAnalyzing(true);
    try {
      await api.analyzeSyllabus(subjectName, rawSyllabus);
      await loadSubjects();
    } catch (err) {
      console.error(err);
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto w-full">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-white tracking-tight">Syllabus & Learning Graph</h1>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 border border-blue-500/20 text-blue-400">
            Syllabus Analyzer Agent
          </span>
        </div>
        <p className="text-sm text-slate-400 mt-1">
          Deconstructs course syllabi into structured learning nodes, estimating difficulty and prerequisite order.
        </p>
      </div>

      {/* Syllabus Ingestion Form */}
      <div className="p-6 rounded-2xl glass-panel border space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-blue-400" />
            Analyze New Course Syllabus
          </h2>
          <span className="text-xs text-slate-400 font-medium">LangGraph Agent Powered</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-slate-300">Subject Name</label>
            <input
              type="text"
              value={subjectName}
              onChange={(e) => setSubjectName(e.target.value)}
              className="mt-1.5 w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500"
              placeholder="e.g. Operating Systems"
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-slate-300">Raw Syllabus / Course Outline</label>
          <textarea
            rows={4}
            value={rawSyllabus}
            onChange={(e) => setRawSyllabus(e.target.value)}
            className="mt-1.5 w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500 leading-relaxed font-mono text-xs"
            placeholder="Paste syllabus modules, chapters, or textbook table of contents..."
          />
        </div>

        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-lg shadow-blue-500/20 border border-blue-400/30 transition flex items-center gap-2 disabled:opacity-50"
        >
          <Sparkles className={`h-4 w-4 ${analyzing ? "animate-spin" : ""}`} />
          <span>{analyzing ? "Deconstructing Syllabus Graph..." : "Analyze with Syllabus Agent"}</span>
        </button>
      </div>

      {/* Structured Subjects & Topics List */}
      <div className="space-y-6">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-blue-400" />
          Active Course Curricula ({subjects.length})
        </h2>

        {subjects.map((subj) => (
          <div key={subj.id} className="p-6 rounded-2xl glass-panel border space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: subj.color || "#3B82F6" }}
                  />
                  {subj.name}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">{subj.description}</p>
              </div>
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-800 text-slate-300">
                {subj.topics?.length || 0} Topics
              </span>
            </div>

            {/* Learning Graph Nodes */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
              {(subj.topics || []).map((topic: any, idx: number) => {
                const masteryScore = topic.mastery?.mastery_score || 0.2;
                const mColor = getMasteryColor(masteryScore);

                return (
                  <div
                    key={topic.id || idx}
                    className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3 relative group hover:border-blue-500/40 transition"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-bold text-slate-400 font-mono">
                        Node {idx + 1}
                      </span>
                      <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${mColor.bg} ${mColor.text} border ${mColor.border}`}>
                        {Math.round(masteryScore * 100)}% Mastery
                      </span>
                    </div>

                    <h4 className="font-semibold text-sm text-white">{topic.name}</h4>
                    <p className="text-xs text-slate-400 line-clamp-2">{topic.description}</p>

                    {/* Metrics */}
                    <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/80 pt-2.5">
                      <span className="flex items-center gap-1">
                        <Sliders className="h-3 w-3 text-blue-400" />
                        Diff: {Math.round((topic.difficulty || 0.5) * 10)}/10
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3 text-purple-400" />
                        {topic.estimated_hours || 2.0}h est.
                      </span>
                    </div>

                    {/* Subtopics */}
                    {topic.subtopics && topic.subtopics.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {topic.subtopics.map((st: any, sIdx: number) => (
                          <span
                            key={sIdx}
                            className="text-[10px] px-2 py-0.5 rounded bg-slate-800/60 text-slate-300"
                          >
                            {st.name || st}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
