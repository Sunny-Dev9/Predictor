"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  CalendarDays,
  Sparkles,
  RotateCw,
  Clock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Play,
  Check,
  X,
  Plus,
} from "lucide-react";
import { api } from "@/lib/api";

export default function PlannerPage() {
  const router = useRouter();
  const [tasks, setTasks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [replanning, setReplanning] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState("ALL");

  const loadTasks = async () => {
    setLoading(true);
    try {
      const data = await api.getCurrentPlan();
      if (data && data.length > 0) {
        setTasks(data);
      } else {
        // Trigger initial plan generation if empty
        const gen = await api.generatePlan(14);
        setTasks(gen.tasks || []);
      }
    } catch (err) {
      console.error("Failed to load plan:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTasks();
  }, []);

  const handleReplan = async () => {
    setReplanning(true);
    try {
      await api.replan("User invoked adaptive replanning to rebalance remaining study blocks.");
      await loadTasks();
    } catch (e) {
      console.error(e);
    } finally {
      setReplanning(false);
    }
  };

  const handleComplete = async (taskId: string) => {
    try {
      await api.completeTask(taskId, 60, "Completed focus session.");
      await loadTasks();
    } catch (e) {
      console.error(e);
    }
  };

  const handleSkip = async (taskId: string) => {
    try {
      await api.skipTask(taskId);
      await loadTasks();
    } catch (e) {
      console.error(e);
    }
  };

  // Group tasks by date
  const groupedTasks: Record<string, any[]> = {};
  tasks.forEach((t) => {
    if (selectedFilter !== "ALL" && t.task_type !== selectedFilter) return;
    const d = t.scheduled_date || "Today";
    if (!groupedTasks[d]) groupedTasks[d] = [];
    groupedTasks[d].push(t);
  });

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto w-full">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-white tracking-tight">Smart Constraint Planner</h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
              OR-Tools / Heuristic
            </span>
          </div>
          <p className="text-sm text-slate-400 mt-1">
            Constraint-optimized schedule respecting daily hours, deadlines, breaks, and spaced repetition.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleReplan}
            disabled={replanning}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-500/20 transition disabled:opacity-50"
          >
            <RotateCw className={`h-3.5 w-3.5 ${replanning ? "animate-spin" : ""}`} />
            <span>{replanning ? "Replanning Agents..." : "Trigger Dynamic Replan"}</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-border/40 pb-3">
        {["ALL", "LEARNING", "REVISION", "PRACTICE"].map((filter) => (
          <button
            key={filter}
            onClick={() => setSelectedFilter(filter)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
              selectedFilter === filter
                ? "bg-blue-600/20 text-blue-400 border border-blue-500/30"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            {filter}
          </button>
        ))}
      </div>

      {/* Schedule Timeline */}
      <div className="space-y-6">
        {Object.keys(groupedTasks).length === 0 && !loading && (
          <div className="p-12 text-center rounded-2xl glass-panel border space-y-3">
            <CalendarDays className="h-10 w-10 text-slate-500 mx-auto" />
            <h3 className="text-slate-200 font-semibold">No tasks scheduled for this filter</h3>
            <p className="text-xs text-slate-400">Click &apos;Trigger Dynamic Replan&apos; to generate schedule blocks.</p>
          </div>
        )}

        {Object.entries(groupedTasks).map(([dateStr, dayTasks]) => (
          <div key={dateStr} className="space-y-3">
            <div className="flex items-center gap-3">
              <span className="text-sm font-bold text-slate-200 px-3 py-1 rounded-lg bg-slate-900 border border-slate-800">
                {new Date(dateStr + "T00:00:00").toLocaleDateString("en-US", {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                })}
              </span>
              <div className="h-px flex-1 bg-border/40" />
            </div>

            <div className="grid grid-cols-1 gap-3">
              {dayTasks.map((task) => {
                const isDone = task.status === "COMPLETED";
                const isSkipped = task.status === "SKIPPED";
                return (
                  <div
                    key={task.id}
                    className={`p-5 rounded-2xl glass-panel border transition-all ${
                      isDone
                        ? "opacity-60 bg-slate-900/40"
                        : "hover:border-blue-500/40 bg-slate-900/80"
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="space-y-1.5 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {task.start_time || "18:00"} - {task.end_time || "19:00"} (60 min)
                          </span>
                          <span className="text-xs font-medium px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300">
                            {task.task_type}
                          </span>
                          <span
                            className={`text-xs font-bold px-2 py-0.5 rounded ${
                              task.priority === "High"
                                ? "text-rose-400 bg-rose-500/10 border border-rose-500/20"
                                : "text-slate-400 bg-slate-800"
                            }`}
                          >
                            {task.priority} Priority
                          </span>
                          {task.is_remedial && (
                            <span className="text-xs font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                              Remedial Topic
                            </span>
                          )}
                        </div>

                        <h3 className="text-base font-bold text-white">{task.title}</h3>

                        {/* Explainable Decision Box */}
                        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-start gap-2.5 mt-2">
                          <HelpCircle className="h-4 w-4 text-blue-400 shrink-0 mt-0.5" />
                          <p className="text-xs text-slate-300 leading-relaxed">
                            <strong className="text-blue-300">Why was this scheduled?</strong> {task.reason}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {!isDone && !isSkipped && (
                          <>
                            <button
                              onClick={() => router.push(`/study?taskId=${task.id}`)}
                              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5 transition shadow"
                            >
                              <Play className="h-3.5 w-3.5" /> Start Study
                            </button>
                            <button
                              onClick={() => handleComplete(task.id)}
                              title="Mark as Completed"
                              className="p-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 transition"
                            >
                              <Check className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleSkip(task.id)}
                              title="Skip Task"
                              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-400 transition"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </>
                        )}
                        {isDone && (
                          <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
                            <CheckCircle2 className="h-4 w-4" /> Completed
                          </span>
                        )}
                        {isSkipped && (
                          <span className="text-xs text-slate-500 font-semibold">Skipped</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
