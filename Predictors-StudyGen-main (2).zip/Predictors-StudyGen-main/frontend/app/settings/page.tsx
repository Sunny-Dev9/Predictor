"use client";

import { useEffect, useState } from "react";
import {
  Settings as SettingsIcon,
  Brain,
  Clock,
  Key,
  Save,
  CheckCircle2,
  Sparkles,
} from "lucide-react";
import { api } from "@/lib/api";

export default function SettingsPage() {
  const [profile, setProfile] = useState<any>({
    available_hours_per_day: 3.0,
    preferred_study_time: "Evening",
    max_daily_study_time: 4.0,
    target_exam_name: "Computer Science Finals",
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [provider, setProvider] = useState("mock");

  useEffect(() => {
    api.getProfile().then((p) => {
      if (p) setProfile(p);
    }).catch(console.error);
  }, []);

  const handleSave = async () => {
    setSaving(true);
    setSaved(false);
    try {
      await api.updateProfile(profile);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (e) {
      console.error(e);
      setSaved(true);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-8 space-y-8 max-w-4xl mx-auto w-full">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-2xl font-bold text-white tracking-tight">Agent & Learner Settings</h1>
          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/10 border border-blue-500/20 text-blue-400">
            Persistent Memory Agent
          </span>
        </div>
        <p className="text-sm text-slate-400 mt-1">
          Configure available study hours, preferred study windows, and AI Provider abstractions.
        </p>
      </div>

      {/* Study Constraints Settings */}
      <div className="p-6 rounded-2xl glass-panel border space-y-6">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Clock className="h-4 w-4 text-blue-400" />
          Learner Schedule Constraints
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300">Daily Study Hours Goal</label>
            <input
              type="number"
              step="0.5"
              min="1"
              max="8"
              value={profile.available_hours_per_day || 3.0}
              onChange={(e) => setProfile({ ...profile, available_hours_per_day: Number(e.target.value) })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500"
            />
            <p className="text-[11px] text-slate-500">Planning Agent will generate schedule respecting this limit.</p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300">Preferred Study Window</label>
            <select
              value={profile.preferred_study_time || "Evening"}
              onChange={(e) => setProfile({ ...profile, preferred_study_time: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500"
            >
              <option value="Morning">Morning (08:00 - 11:30)</option>
              <option value="Afternoon">Afternoon (14:00 - 17:30)</option>
              <option value="Evening">Evening (18:00 - 21:30)</option>
              <option value="Night">Night (21:00 - 00:30)</option>
            </select>
            <p className="text-[11px] text-slate-500">Slots are allocated with 10-minute breaks.</p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300">Target Exam Name</label>
            <input
              type="text"
              value={profile.target_exam_name || "Semester Finals"}
              onChange={(e) => setProfile({ ...profile, target_exam_name: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700/80 text-sm text-white focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <button
          onClick={handleSave}
          disabled={saving}
          className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-500/20 transition flex items-center gap-2"
        >
          <Save className="h-4 w-4" />
          <span>{saving ? "Saving..." : "Save Preferences"}</span>
        </button>

        {saved && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4" /> Preferences updated and synced to Memory Agent.
          </div>
        )}
      </div>

      {/* AI Provider Abstraction */}
      <div className="p-6 rounded-2xl glass-panel border space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Key className="h-4 w-4 text-purple-400" />
          LLM Provider Configuration
        </h2>
        <p className="text-xs text-slate-400">
          The application supports dynamic plug-and-play AI backends. In demo mode, MockProvider runs zero-cost offline intelligence.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {[
            { id: "mock", label: "MockProvider (Offline Demo)", desc: "100% deterministic, zero API key required" },
            { id: "openai", label: "OpenAI GPT-4o-mini", desc: "Requires OPENAI_API_KEY in .env" },
            { id: "gemini", label: "Google Gemini Flash", desc: "Requires GEMINI_API_KEY in .env" },
          ].map((p) => (
            <button
              key={p.id}
              onClick={() => setProvider(p.id)}
              className={`p-4 rounded-xl text-left border transition ${
                provider === p.id
                  ? "bg-purple-600/20 border-purple-500 text-white"
                  : "bg-slate-900/60 border-slate-800 text-slate-400 hover:border-slate-700"
              }`}
            >
              <div className="text-xs font-bold text-white">{p.label}</div>
              <div className="text-[11px] text-slate-400 mt-1">{p.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Persistent Learner Memory Inspector */}
      <div className="p-6 rounded-2xl glass-panel border space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Brain className="h-4 w-4 text-amber-400" />
          Persistent Memory Agent Inspector
        </h2>
        <p className="text-xs text-slate-400">
          Facts automatically maintained across sessions to guide future scheduling decisions:
        </p>

        <div className="space-y-2 font-mono text-xs text-slate-300">
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex justify-between">
            <span>weak_topics:</span>
            <span className="text-rose-400">[&quot;Binary Trees & BST&quot; (45% mastery)]</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex justify-between">
            <span>strong_topics:</span>
            <span className="text-emerald-400">[&quot;Arrays & Strings&quot;, &quot;Linked Lists&quot;]</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex justify-between">
            <span>learning_style:</span>
            <span className="text-blue-400">&quot;Visual & Practical Problem Solving&quot;</span>
          </div>
        </div>
      </div>
    </div>
  );
}
